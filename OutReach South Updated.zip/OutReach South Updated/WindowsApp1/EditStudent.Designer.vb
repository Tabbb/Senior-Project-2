﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmEditStudent
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.btnUnselect = New System.Windows.Forms.Button()
        Me.dgvParents = New System.Windows.Forms.DataGridView()
        Me.ParentIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ParentFirstNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ParentLastNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AlumniDataGridViewCheckBoxColumn = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.TblParentBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.OutreachDataSet = New WindowsApp1.OutreachDataSet()
        Me.lblAddParent = New System.Windows.Forms.Label()
        Me.btnAddParent = New System.Windows.Forms.Button()
        Me.lblParent = New System.Windows.Forms.Label()
        Me.radMr = New System.Windows.Forms.RadioButton()
        Me.radMs = New System.Windows.Forms.RadioButton()
        Me.txtHome = New System.Windows.Forms.MaskedTextBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.txtStudentLast = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txtDOB = New System.Windows.Forms.MaskedTextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txtCell = New System.Windows.Forms.MaskedTextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.cboState = New System.Windows.Forms.ComboBox()
        Me.txtZip = New System.Windows.Forms.MaskedTextBox()
        Me.txtCity = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtStreet = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtStudentMiddle = New System.Windows.Forms.TextBox()
        Me.txtStudentFirst = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cboCollege = New System.Windows.Forms.ComboBox()
        Me.TblCollegeBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.btnCreateCollege = New System.Windows.Forms.Button()
        Me.btnCreateHighSchool = New System.Windows.Forms.Button()
        Me.cboHighSchool = New System.Windows.Forms.ComboBox()
        Me.TblHighSchoolBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.lblClassification = New System.Windows.Forms.Label()
        Me.cboClassification = New System.Windows.Forms.ComboBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.radSummer = New System.Windows.Forms.RadioButton()
        Me.radFall = New System.Windows.Forms.RadioButton()
        Me.radSpring = New System.Windows.Forms.RadioButton()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.cmbPhase = New System.Windows.Forms.ComboBox()
        Me.txtMajor = New System.Windows.Forms.TextBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.chkTransfer = New System.Windows.Forms.CheckBox()
        Me.txtGPA = New System.Windows.Forms.TextBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.txtEnroll = New System.Windows.Forms.MaskedTextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.lblCollege = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.txtSAT = New System.Windows.Forms.TextBox()
        Me.txtACT = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.txtGradYear = New System.Windows.Forms.MaskedTextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnSubmit = New System.Windows.Forms.Button()
        Me.lblStudentID = New System.Windows.Forms.Label()
        Me.txtStudentID = New System.Windows.Forms.TextBox()
        Me.TblParentTableAdapter = New WindowsApp1.OutreachDataSetTableAdapters.tblParentTableAdapter()
        Me.TblHighSchoolTableAdapter = New WindowsApp1.OutreachDataSetTableAdapters.tblHighSchoolTableAdapter()
        Me.TblCollegeTableAdapter = New WindowsApp1.OutreachDataSetTableAdapters.tblCollegeTableAdapter()
        Me.lblSearchParent = New System.Windows.Forms.Label()
        Me.btnSearchParent = New System.Windows.Forms.Button()
        Me.txtParentLast = New System.Windows.Forms.TextBox()
        Me.btnDisplayParents = New System.Windows.Forms.Button()
        CType(Me.dgvParents, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblParentBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.OutreachDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblCollegeBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblHighSchoolBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(545, 9)
        Me.Label21.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(239, 29)
        Me.Label21.TabIndex = 105
        Me.Label21.Text = "Student Information"
        '
        'btnUnselect
        '
        Me.btnUnselect.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUnselect.Location = New System.Drawing.Point(453, 206)
        Me.btnUnselect.Margin = New System.Windows.Forms.Padding(4)
        Me.btnUnselect.Name = "btnUnselect"
        Me.btnUnselect.Size = New System.Drawing.Size(202, 37)
        Me.btnUnselect.TabIndex = 132
        Me.btnUnselect.Text = "Unselect Parent"
        Me.btnUnselect.UseVisualStyleBackColor = True
        '
        'dgvParents
        '
        Me.dgvParents.AllowUserToAddRows = False
        Me.dgvParents.AllowUserToDeleteRows = False
        Me.dgvParents.AllowUserToOrderColumns = True
        Me.dgvParents.AutoGenerateColumns = False
        Me.dgvParents.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvParents.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.ParentIDDataGridViewTextBoxColumn, Me.ParentFirstNameDataGridViewTextBoxColumn, Me.ParentLastNameDataGridViewTextBoxColumn, Me.AlumniDataGridViewCheckBoxColumn})
        Me.dgvParents.DataSource = Me.TblParentBindingSource
        Me.dgvParents.Location = New System.Drawing.Point(37, 250)
        Me.dgvParents.Name = "dgvParents"
        Me.dgvParents.ReadOnly = True
        Me.dgvParents.RowTemplate.Height = 24
        Me.dgvParents.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvParents.Size = New System.Drawing.Size(624, 199)
        Me.dgvParents.TabIndex = 140
        '
        'ParentIDDataGridViewTextBoxColumn
        '
        Me.ParentIDDataGridViewTextBoxColumn.DataPropertyName = "ParentID"
        Me.ParentIDDataGridViewTextBoxColumn.HeaderText = "ParentID"
        Me.ParentIDDataGridViewTextBoxColumn.Name = "ParentIDDataGridViewTextBoxColumn"
        Me.ParentIDDataGridViewTextBoxColumn.ReadOnly = True
        '
        'ParentFirstNameDataGridViewTextBoxColumn
        '
        Me.ParentFirstNameDataGridViewTextBoxColumn.DataPropertyName = "ParentFirstName"
        Me.ParentFirstNameDataGridViewTextBoxColumn.HeaderText = "ParentFirstName"
        Me.ParentFirstNameDataGridViewTextBoxColumn.Name = "ParentFirstNameDataGridViewTextBoxColumn"
        Me.ParentFirstNameDataGridViewTextBoxColumn.ReadOnly = True
        '
        'ParentLastNameDataGridViewTextBoxColumn
        '
        Me.ParentLastNameDataGridViewTextBoxColumn.DataPropertyName = "ParentLastName"
        Me.ParentLastNameDataGridViewTextBoxColumn.HeaderText = "ParentLastName"
        Me.ParentLastNameDataGridViewTextBoxColumn.Name = "ParentLastNameDataGridViewTextBoxColumn"
        Me.ParentLastNameDataGridViewTextBoxColumn.ReadOnly = True
        '
        'AlumniDataGridViewCheckBoxColumn
        '
        Me.AlumniDataGridViewCheckBoxColumn.DataPropertyName = "Alumni"
        Me.AlumniDataGridViewCheckBoxColumn.HeaderText = "Alumni"
        Me.AlumniDataGridViewCheckBoxColumn.Name = "AlumniDataGridViewCheckBoxColumn"
        Me.AlumniDataGridViewCheckBoxColumn.ReadOnly = True
        '
        'TblParentBindingSource
        '
        Me.TblParentBindingSource.DataMember = "tblParent"
        Me.TblParentBindingSource.DataSource = Me.OutreachDataSet
        '
        'OutreachDataSet
        '
        Me.OutreachDataSet.DataSetName = "OutreachDataSet"
        Me.OutreachDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'lblAddParent
        '
        Me.lblAddParent.AutoSize = True
        Me.lblAddParent.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAddParent.Location = New System.Drawing.Point(678, 370)
        Me.lblAddParent.Name = "lblAddParent"
        Me.lblAddParent.Size = New System.Drawing.Size(213, 36)
        Me.lblAddParent.TabIndex = 139
        Me.lblAddParent.Text = "If parent does not exist, " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "select to add a new parent here"
        '
        'btnAddParent
        '
        Me.btnAddParent.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAddParent.Location = New System.Drawing.Point(920, 369)
        Me.btnAddParent.Margin = New System.Windows.Forms.Padding(4)
        Me.btnAddParent.Name = "btnAddParent"
        Me.btnAddParent.Size = New System.Drawing.Size(145, 37)
        Me.btnAddParent.TabIndex = 135
        Me.btnAddParent.Text = "Add Parent"
        Me.btnAddParent.UseVisualStyleBackColor = True
        '
        'lblParent
        '
        Me.lblParent.AutoSize = True
        Me.lblParent.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblParent.Location = New System.Drawing.Point(35, 215)
        Me.lblParent.Name = "lblParent"
        Me.lblParent.Size = New System.Drawing.Size(157, 18)
        Me.lblParent.TabIndex = 138
        Me.lblParent.Text = "Please select a parent:"
        '
        'radMr
        '
        Me.radMr.AutoSize = True
        Me.radMr.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radMr.Location = New System.Drawing.Point(91, 106)
        Me.radMr.Name = "radMr"
        Me.radMr.Size = New System.Drawing.Size(47, 22)
        Me.radMr.TabIndex = 108
        Me.radMr.TabStop = True
        Me.radMr.Text = "Mr"
        Me.radMr.UseVisualStyleBackColor = True
        '
        'radMs
        '
        Me.radMs.AutoSize = True
        Me.radMs.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radMs.Location = New System.Drawing.Point(35, 106)
        Me.radMs.Name = "radMs"
        Me.radMs.Size = New System.Drawing.Size(50, 22)
        Me.radMs.TabIndex = 106
        Me.radMs.TabStop = True
        Me.radMs.Text = "Ms"
        Me.radMs.UseVisualStyleBackColor = True
        '
        'txtHome
        '
        Me.txtHome.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtHome.Location = New System.Drawing.Point(1075, 142)
        Me.txtHome.Margin = New System.Windows.Forms.Padding(4)
        Me.txtHome.Mask = "(999) 000-0000"
        Me.txtHome.Name = "txtHome"
        Me.txtHome.Size = New System.Drawing.Size(153, 24)
        Me.txtHome.TabIndex = 116
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(955, 145)
        Me.Label28.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(110, 18)
        Me.Label28.TabIndex = 137
        Me.Label28.Text = "Home Number:"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(15, 181)
        Me.Label23.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(164, 20)
        Me.Label23.TabIndex = 136
        Me.Label23.Text = "Parent Information"
        '
        'txtStudentLast
        '
        Me.txtStudentLast.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtStudentLast.Location = New System.Drawing.Point(757, 100)
        Me.txtStudentLast.Margin = New System.Windows.Forms.Padding(4)
        Me.txtStudentLast.Name = "txtStudentLast"
        Me.txtStudentLast.Size = New System.Drawing.Size(247, 24)
        Me.txtStudentLast.TabIndex = 111
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(26, 145)
        Me.Label13.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(104, 18)
        Me.Label13.TabIndex = 131
        Me.Label13.Text = "* Date of Birth:"
        '
        'txtDOB
        '
        Me.txtDOB.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDOB.Location = New System.Drawing.Point(153, 142)
        Me.txtDOB.Margin = New System.Windows.Forms.Padding(4)
        Me.txtDOB.Mask = "00/00/0000"
        Me.txtDOB.Name = "txtDOB"
        Me.txtDOB.Size = New System.Drawing.Size(112, 24)
        Me.txtDOB.TabIndex = 113
        Me.txtDOB.ValidatingType = GetType(Date)
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(299, 145)
        Me.Label12.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(59, 18)
        Me.Label12.TabIndex = 130
        Me.Label12.Text = "* Email:"
        '
        'txtEmail
        '
        Me.txtEmail.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEmail.Location = New System.Drawing.Point(376, 142)
        Me.txtEmail.Margin = New System.Windows.Forms.Padding(4)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(275, 24)
        Me.txtEmail.TabIndex = 114
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(674, 148)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(94, 18)
        Me.Label11.TabIndex = 129
        Me.Label11.Text = "Cell Number:"
        '
        'txtCell
        '
        Me.txtCell.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCell.Location = New System.Drawing.Point(780, 142)
        Me.txtCell.Margin = New System.Windows.Forms.Padding(4)
        Me.txtCell.Mask = "(999) 000-0000"
        Me.txtCell.Name = "txtCell"
        Me.txtCell.Size = New System.Drawing.Size(145, 24)
        Me.txtCell.TabIndex = 115
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(948, 503)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(32, 18)
        Me.Label10.TabIndex = 128
        Me.Label10.Text = "Zip:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(672, 502)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(46, 18)
        Me.Label9.TabIndex = 127
        Me.Label9.Text = "State:"
        '
        'cboState
        '
        Me.cboState.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboState.FormattingEnabled = True
        Me.cboState.Items.AddRange(New Object() {"Alabama ", "Alaska ", "Arizona ", "Arkansas ", "California ", "Colorado ", "Connecticut ", "Delaware ", "Florida ", "Georgia ", "Hawaii ", "Idaho ", "Illinois Indiana ", "Iowa ", "Kansas ", "Kentucky ", "Louisiana ", "Maine ", "Maryland ", "Massachusetts ", "Michigan ", "Minnesota ", "Mississippi ", "Missouri ", "Montana Nebraska ", "Nevada ", "New Hampshire ", "New Jersey ", "New Mexico ", "New York ", "North Carolina ", "North Dakota ", "Ohio ", "Oklahoma ", "Oregon ", "Pennsylvania Rhode Island ", "South Carolina ", "South Dakota ", "Tennessee ", "Texas ", "Utah ", "Vermont ", "Virginia ", "Washington ", "West Virginia ", "Wisconsin ", "Wyoming"})
        Me.cboState.Location = New System.Drawing.Point(733, 498)
        Me.cboState.Margin = New System.Windows.Forms.Padding(4)
        Me.cboState.Name = "cboState"
        Me.cboState.Size = New System.Drawing.Size(192, 26)
        Me.cboState.TabIndex = 120
        '
        'txtZip
        '
        Me.txtZip.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtZip.Location = New System.Drawing.Point(988, 501)
        Me.txtZip.Margin = New System.Windows.Forms.Padding(4)
        Me.txtZip.Mask = "00000"
        Me.txtZip.Name = "txtZip"
        Me.txtZip.Size = New System.Drawing.Size(77, 24)
        Me.txtZip.TabIndex = 123
        Me.txtZip.ValidatingType = GetType(Integer)
        '
        'txtCity
        '
        Me.txtCity.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCity.Location = New System.Drawing.Point(1141, 500)
        Me.txtCity.Margin = New System.Windows.Forms.Padding(4)
        Me.txtCity.Name = "txtCity"
        Me.txtCity.Size = New System.Drawing.Size(176, 24)
        Me.txtCity.TabIndex = 124
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(1090, 503)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(37, 18)
        Me.Label8.TabIndex = 126
        Me.Label8.Text = "City:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(35, 503)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(51, 18)
        Me.Label7.TabIndex = 125
        Me.Label7.Text = "Street:"
        '
        'txtStreet
        '
        Me.txtStreet.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtStreet.Location = New System.Drawing.Point(102, 500)
        Me.txtStreet.Margin = New System.Windows.Forms.Padding(4)
        Me.txtStreet.Name = "txtStreet"
        Me.txtStreet.Size = New System.Drawing.Size(553, 24)
        Me.txtStreet.TabIndex = 118
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(15, 461)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(78, 20)
        Me.Label6.TabIndex = 122
        Me.Label6.Text = "Address"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(688, 103)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(50, 18)
        Me.Label5.TabIndex = 121
        Me.Label5.Text = "* Last:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(450, 106)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(55, 18)
        Me.Label4.TabIndex = 119
        Me.Label4.Text = "Middle:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(150, 106)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(51, 18)
        Me.Label3.TabIndex = 117
        Me.Label3.Text = "* First:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(22, 80)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(79, 18)
        Me.Label2.TabIndex = 112
        Me.Label2.Text = "Full Name:"
        '
        'txtStudentMiddle
        '
        Me.txtStudentMiddle.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtStudentMiddle.Location = New System.Drawing.Point(517, 103)
        Me.txtStudentMiddle.Margin = New System.Windows.Forms.Padding(4)
        Me.txtStudentMiddle.Name = "txtStudentMiddle"
        Me.txtStudentMiddle.Size = New System.Drawing.Size(144, 24)
        Me.txtStudentMiddle.TabIndex = 110
        '
        'txtStudentFirst
        '
        Me.txtStudentFirst.AcceptsTab = True
        Me.txtStudentFirst.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtStudentFirst.Location = New System.Drawing.Point(209, 103)
        Me.txtStudentFirst.Margin = New System.Windows.Forms.Padding(4)
        Me.txtStudentFirst.Name = "txtStudentFirst"
        Me.txtStudentFirst.Size = New System.Drawing.Size(216, 24)
        Me.txtStudentFirst.TabIndex = 109
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(15, 57)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(173, 20)
        Me.Label1.TabIndex = 107
        Me.Label1.Text = "Student Information"
        '
        'cboCollege
        '
        Me.cboCollege.DataSource = Me.TblCollegeBindingSource
        Me.cboCollege.DisplayMember = "CollegeName"
        Me.cboCollege.FormattingEnabled = True
        Me.cboCollege.Location = New System.Drawing.Point(162, 611)
        Me.cboCollege.Name = "cboCollege"
        Me.cboCollege.Size = New System.Drawing.Size(260, 24)
        Me.cboCollege.TabIndex = 146
        Me.cboCollege.ValueMember = "CollegeID"
        '
        'TblCollegeBindingSource
        '
        Me.TblCollegeBindingSource.DataMember = "tblCollege"
        Me.TblCollegeBindingSource.DataSource = Me.OutreachDataSet
        '
        'btnCreateCollege
        '
        Me.btnCreateCollege.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCreateCollege.Location = New System.Drawing.Point(437, 609)
        Me.btnCreateCollege.Margin = New System.Windows.Forms.Padding(4)
        Me.btnCreateCollege.Name = "btnCreateCollege"
        Me.btnCreateCollege.Size = New System.Drawing.Size(214, 28)
        Me.btnCreateCollege.TabIndex = 147
        Me.btnCreateCollege.Text = "Create College"
        Me.btnCreateCollege.UseVisualStyleBackColor = True
        '
        'btnCreateHighSchool
        '
        Me.btnCreateHighSchool.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCreateHighSchool.Location = New System.Drawing.Point(437, 566)
        Me.btnCreateHighSchool.Margin = New System.Windows.Forms.Padding(4)
        Me.btnCreateHighSchool.Name = "btnCreateHighSchool"
        Me.btnCreateHighSchool.Size = New System.Drawing.Size(214, 28)
        Me.btnCreateHighSchool.TabIndex = 143
        Me.btnCreateHighSchool.Text = "Create High School"
        Me.btnCreateHighSchool.UseVisualStyleBackColor = True
        '
        'cboHighSchool
        '
        Me.cboHighSchool.DataSource = Me.TblHighSchoolBindingSource
        Me.cboHighSchool.DisplayMember = "HighSchoolName"
        Me.cboHighSchool.FormattingEnabled = True
        Me.cboHighSchool.Location = New System.Drawing.Point(162, 570)
        Me.cboHighSchool.Name = "cboHighSchool"
        Me.cboHighSchool.Size = New System.Drawing.Size(260, 24)
        Me.cboHighSchool.TabIndex = 142
        Me.cboHighSchool.ValueMember = "HighSchoolID"
        '
        'TblHighSchoolBindingSource
        '
        Me.TblHighSchoolBindingSource.DataMember = "tblHighSchool"
        Me.TblHighSchoolBindingSource.DataSource = Me.OutreachDataSet
        '
        'lblClassification
        '
        Me.lblClassification.AutoSize = True
        Me.lblClassification.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblClassification.Location = New System.Drawing.Point(715, 571)
        Me.lblClassification.Name = "lblClassification"
        Me.lblClassification.Size = New System.Drawing.Size(100, 18)
        Me.lblClassification.TabIndex = 171
        Me.lblClassification.Text = "Classification:"
        '
        'cboClassification
        '
        Me.cboClassification.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboClassification.FormattingEnabled = True
        Me.cboClassification.Items.AddRange(New Object() {"Junior", "Senior"})
        Me.cboClassification.Location = New System.Drawing.Point(832, 568)
        Me.cboClassification.Name = "cboClassification"
        Me.cboClassification.Size = New System.Drawing.Size(187, 26)
        Me.cboClassification.TabIndex = 144
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.radSummer)
        Me.GroupBox1.Controls.Add(Me.radFall)
        Me.GroupBox1.Controls.Add(Me.radSpring)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(663, 688)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(225, 114)
        Me.GroupBox1.TabIndex = 154
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Semester"
        '
        'radSummer
        '
        Me.radSummer.AutoSize = True
        Me.radSummer.Location = New System.Drawing.Point(28, 79)
        Me.radSummer.Name = "radSummer"
        Me.radSummer.Size = New System.Drawing.Size(132, 22)
        Me.radSummer.TabIndex = 28
        Me.radSummer.TabStop = True
        Me.radSummer.Text = "Summer (June)"
        Me.radSummer.UseVisualStyleBackColor = True
        '
        'radFall
        '
        Me.radFall.AutoSize = True
        Me.radFall.Location = New System.Drawing.Point(28, 51)
        Me.radFall.Name = "radFall"
        Me.radFall.Size = New System.Drawing.Size(111, 22)
        Me.radFall.TabIndex = 27
        Me.radFall.TabStop = True
        Me.radFall.Text = "Fall (August)"
        Me.radFall.UseVisualStyleBackColor = True
        '
        'radSpring
        '
        Me.radSpring.AutoSize = True
        Me.radSpring.Location = New System.Drawing.Point(28, 23)
        Me.radSpring.Name = "radSpring"
        Me.radSpring.Size = New System.Drawing.Size(137, 22)
        Me.radSpring.TabIndex = 26
        Me.radSpring.TabStop = True
        Me.radSpring.Text = "Spring (January)"
        Me.radSpring.UseVisualStyleBackColor = True
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(15, 769)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(61, 20)
        Me.Label30.TabIndex = 170
        Me.Label30.Text = "Phase"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(69, 789)
        Me.Label29.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(137, 18)
        Me.Label29.TabIndex = 169
        Me.Label29.Text = "* Phase of Contact:"
        '
        'cmbPhase
        '
        Me.cmbPhase.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbPhase.FormattingEnabled = True
        Me.cmbPhase.Items.AddRange(New Object() {"Initial Meeting", "Email", "Mail ", "Phone Call"})
        Me.cmbPhase.Location = New System.Drawing.Point(246, 786)
        Me.cmbPhase.Margin = New System.Windows.Forms.Padding(4)
        Me.cmbPhase.Name = "cmbPhase"
        Me.cmbPhase.Size = New System.Drawing.Size(218, 26)
        Me.cmbPhase.TabIndex = 157
        '
        'txtMajor
        '
        Me.txtMajor.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMajor.Location = New System.Drawing.Point(1126, 609)
        Me.txtMajor.Margin = New System.Windows.Forms.Padding(4)
        Me.txtMajor.Name = "txtMajor"
        Me.txtMajor.Size = New System.Drawing.Size(191, 24)
        Me.txtMajor.TabIndex = 150
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(1068, 614)
        Me.Label27.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(50, 18)
        Me.Label27.TabIndex = 168
        Me.Label27.Text = "Major:"
        '
        'chkTransfer
        '
        Me.chkTransfer.AutoSize = True
        Me.chkTransfer.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkTransfer.Location = New System.Drawing.Point(697, 611)
        Me.chkTransfer.Margin = New System.Windows.Forms.Padding(4)
        Me.chkTransfer.Name = "chkTransfer"
        Me.chkTransfer.Size = New System.Drawing.Size(131, 22)
        Me.chkTransfer.TabIndex = 148
        Me.chkTransfer.Text = "Tranfer Student"
        Me.chkTransfer.UseVisualStyleBackColor = True
        '
        'txtGPA
        '
        Me.txtGPA.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtGPA.Location = New System.Drawing.Point(979, 609)
        Me.txtGPA.Margin = New System.Windows.Forms.Padding(4)
        Me.txtGPA.MaxLength = 4
        Me.txtGPA.Name = "txtGPA"
        Me.txtGPA.Size = New System.Drawing.Size(61, 24)
        Me.txtGPA.TabIndex = 149
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(853, 612)
        Me.Label26.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(118, 18)
        Me.Label26.TabIndex = 167
        Me.Label26.Text = "GPA (4.0 Scale):"
        '
        'btnClose
        '
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClose.Location = New System.Drawing.Point(1184, 691)
        Me.btnClose.Margin = New System.Windows.Forms.Padding(4)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(100, 42)
        Me.btnClose.TabIndex = 161
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'txtEnroll
        '
        Me.txtEnroll.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEnroll.Location = New System.Drawing.Point(567, 688)
        Me.txtEnroll.Margin = New System.Windows.Forms.Padding(4)
        Me.txtEnroll.Mask = "####"
        Me.txtEnroll.Name = "txtEnroll"
        Me.txtEnroll.Size = New System.Drawing.Size(65, 24)
        Me.txtEnroll.TabIndex = 153
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(269, 691)
        Me.Label22.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(265, 18)
        Me.Label22.TabIndex = 166
        Me.Label22.Text = "Year the student plans to enroll to USA:"
        '
        'lblCollege
        '
        Me.lblCollege.AutoSize = True
        Me.lblCollege.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCollege.Location = New System.Drawing.Point(15, 612)
        Me.lblCollege.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblCollege.Name = "lblCollege"
        Me.lblCollege.Size = New System.Drawing.Size(123, 18)
        Me.lblCollege.TabIndex = 165
        Me.lblCollege.Text = "College Attended:"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(69, 729)
        Me.Label19.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(36, 18)
        Me.Label19.TabIndex = 164
        Me.Label19.Text = "SAT"
        '
        'txtSAT
        '
        Me.txtSAT.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSAT.Location = New System.Drawing.Point(118, 726)
        Me.txtSAT.Margin = New System.Windows.Forms.Padding(4)
        Me.txtSAT.MaxLength = 4
        Me.txtSAT.Name = "txtSAT"
        Me.txtSAT.Size = New System.Drawing.Size(56, 24)
        Me.txtSAT.TabIndex = 152
        '
        'txtACT
        '
        Me.txtACT.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtACT.Location = New System.Drawing.Point(118, 685)
        Me.txtACT.Margin = New System.Windows.Forms.Padding(4)
        Me.txtACT.MaxLength = 2
        Me.txtACT.Name = "txtACT"
        Me.txtACT.Size = New System.Drawing.Size(56, 24)
        Me.txtACT.TabIndex = 151
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(68, 688)
        Me.Label18.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(37, 18)
        Me.Label18.TabIndex = 163
        Me.Label18.Text = "ACT"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(35, 656)
        Me.Label17.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(60, 18)
        Me.Label17.TabIndex = 162
        Me.Label17.Text = "Scores:"
        '
        'txtGradYear
        '
        Me.txtGradYear.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtGradYear.Location = New System.Drawing.Point(1184, 568)
        Me.txtGradYear.Margin = New System.Windows.Forms.Padding(4)
        Me.txtGradYear.Mask = "####"
        Me.txtGradYear.Name = "txtGradYear"
        Me.txtGradYear.Size = New System.Drawing.Size(56, 24)
        Me.txtGradYear.TabIndex = 145
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(1028, 571)
        Me.Label16.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(129, 18)
        Me.Label16.TabIndex = 158
        Me.Label16.Text = "* Graduation Year:"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(45, 574)
        Me.Label15.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(93, 18)
        Me.Label15.TabIndex = 156
        Me.Label15.Text = "High School:"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(15, 536)
        Me.Label14.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(92, 20)
        Me.Label14.TabIndex = 155
        Me.Label14.Text = "Education"
        '
        'btnClear
        '
        Me.btnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.Location = New System.Drawing.Point(1058, 691)
        Me.btnClear.Margin = New System.Windows.Forms.Padding(4)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(100, 42)
        Me.btnClear.TabIndex = 160
        Me.btnClear.Text = "Clear All"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnSubmit
        '
        Me.btnSubmit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSubmit.Location = New System.Drawing.Point(934, 691)
        Me.btnSubmit.Margin = New System.Windows.Forms.Padding(4)
        Me.btnSubmit.Name = "btnSubmit"
        Me.btnSubmit.Size = New System.Drawing.Size(100, 42)
        Me.btnSubmit.TabIndex = 159
        Me.btnSubmit.Text = "Submit"
        Me.btnSubmit.UseVisualStyleBackColor = True
        '
        'lblStudentID
        '
        Me.lblStudentID.AutoSize = True
        Me.lblStudentID.Location = New System.Drawing.Point(554, 57)
        Me.lblStudentID.Name = "lblStudentID"
        Me.lblStudentID.Size = New System.Drawing.Size(78, 17)
        Me.lblStudentID.TabIndex = 172
        Me.lblStudentID.Text = "Student ID:"
        '
        'txtStudentID
        '
        Me.txtStudentID.Location = New System.Drawing.Point(638, 54)
        Me.txtStudentID.Name = "txtStudentID"
        Me.txtStudentID.ReadOnly = True
        Me.txtStudentID.Size = New System.Drawing.Size(130, 22)
        Me.txtStudentID.TabIndex = 173
        '
        'TblParentTableAdapter
        '
        Me.TblParentTableAdapter.ClearBeforeFill = True
        '
        'TblHighSchoolTableAdapter
        '
        Me.TblHighSchoolTableAdapter.ClearBeforeFill = True
        '
        'TblCollegeTableAdapter
        '
        Me.TblCollegeTableAdapter.ClearBeforeFill = True
        '
        'lblSearchParent
        '
        Me.lblSearchParent.AutoSize = True
        Me.lblSearchParent.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSearchParent.Location = New System.Drawing.Point(678, 267)
        Me.lblSearchParent.Name = "lblSearchParent"
        Me.lblSearchParent.Size = New System.Drawing.Size(225, 18)
        Me.lblSearchParent.TabIndex = 141
        Me.lblSearchParent.Text = "Search for a parent by last name:"
        '
        'btnSearchParent
        '
        Me.btnSearchParent.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSearchParent.Location = New System.Drawing.Point(884, 295)
        Me.btnSearchParent.Margin = New System.Windows.Forms.Padding(4)
        Me.btnSearchParent.Name = "btnSearchParent"
        Me.btnSearchParent.Size = New System.Drawing.Size(234, 38)
        Me.btnSearchParent.TabIndex = 134
        Me.btnSearchParent.Text = "Search for a Parent"
        Me.btnSearchParent.UseVisualStyleBackColor = True
        '
        'txtParentLast
        '
        Me.txtParentLast.Location = New System.Drawing.Point(937, 266)
        Me.txtParentLast.Name = "txtParentLast"
        Me.txtParentLast.Size = New System.Drawing.Size(181, 22)
        Me.txtParentLast.TabIndex = 133
        '
        'btnDisplayParents
        '
        Me.btnDisplayParents.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDisplayParents.Location = New System.Drawing.Point(222, 206)
        Me.btnDisplayParents.Margin = New System.Windows.Forms.Padding(4)
        Me.btnDisplayParents.Name = "btnDisplayParents"
        Me.btnDisplayParents.Size = New System.Drawing.Size(223, 37)
        Me.btnDisplayParents.TabIndex = 174
        Me.btnDisplayParents.Text = "Display All Parents"
        Me.btnDisplayParents.UseVisualStyleBackColor = True
        '
        'frmEditStudent
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1336, 845)
        Me.Controls.Add(Me.btnDisplayParents)
        Me.Controls.Add(Me.txtStudentID)
        Me.Controls.Add(Me.lblStudentID)
        Me.Controls.Add(Me.cboCollege)
        Me.Controls.Add(Me.btnCreateCollege)
        Me.Controls.Add(Me.btnCreateHighSchool)
        Me.Controls.Add(Me.cboHighSchool)
        Me.Controls.Add(Me.lblClassification)
        Me.Controls.Add(Me.cboClassification)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label30)
        Me.Controls.Add(Me.Label29)
        Me.Controls.Add(Me.cmbPhase)
        Me.Controls.Add(Me.txtMajor)
        Me.Controls.Add(Me.Label27)
        Me.Controls.Add(Me.chkTransfer)
        Me.Controls.Add(Me.txtGPA)
        Me.Controls.Add(Me.Label26)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.txtEnroll)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.lblCollege)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.txtSAT)
        Me.Controls.Add(Me.txtACT)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.txtGradYear)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnSubmit)
        Me.Controls.Add(Me.btnUnselect)
        Me.Controls.Add(Me.btnSearchParent)
        Me.Controls.Add(Me.txtParentLast)
        Me.Controls.Add(Me.lblSearchParent)
        Me.Controls.Add(Me.dgvParents)
        Me.Controls.Add(Me.lblAddParent)
        Me.Controls.Add(Me.btnAddParent)
        Me.Controls.Add(Me.lblParent)
        Me.Controls.Add(Me.radMr)
        Me.Controls.Add(Me.radMs)
        Me.Controls.Add(Me.txtHome)
        Me.Controls.Add(Me.Label28)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.txtStudentLast)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.txtDOB)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.txtEmail)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.txtCell)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.cboState)
        Me.Controls.Add(Me.txtZip)
        Me.Controls.Add(Me.txtCity)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.txtStreet)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtStudentMiddle)
        Me.Controls.Add(Me.txtStudentFirst)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label21)
        Me.Name = "frmEditStudent"
        Me.Text = "Edit Student"
        CType(Me.dgvParents, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblParentBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.OutreachDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblCollegeBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblHighSchoolBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents btnUnselect As System.Windows.Forms.Button
    Friend WithEvents dgvParents As System.Windows.Forms.DataGridView
    Friend WithEvents lblAddParent As System.Windows.Forms.Label
    Friend WithEvents btnAddParent As System.Windows.Forms.Button
    Friend WithEvents lblParent As System.Windows.Forms.Label
    Friend WithEvents radMr As System.Windows.Forms.RadioButton
    Friend WithEvents radMs As System.Windows.Forms.RadioButton
    Friend WithEvents txtHome As System.Windows.Forms.MaskedTextBox
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents txtStudentLast As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents txtDOB As System.Windows.Forms.MaskedTextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents txtEmail As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents txtCell As System.Windows.Forms.MaskedTextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents cboState As System.Windows.Forms.ComboBox
    Friend WithEvents txtZip As System.Windows.Forms.MaskedTextBox
    Friend WithEvents txtCity As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtStreet As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtStudentMiddle As System.Windows.Forms.TextBox
    Friend WithEvents txtStudentFirst As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cboCollege As System.Windows.Forms.ComboBox
    Friend WithEvents btnCreateCollege As System.Windows.Forms.Button
    Friend WithEvents btnCreateHighSchool As System.Windows.Forms.Button
    Friend WithEvents cboHighSchool As System.Windows.Forms.ComboBox
    Friend WithEvents lblClassification As System.Windows.Forms.Label
    Friend WithEvents cboClassification As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents radSummer As System.Windows.Forms.RadioButton
    Friend WithEvents radFall As System.Windows.Forms.RadioButton
    Friend WithEvents radSpring As System.Windows.Forms.RadioButton
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents cmbPhase As System.Windows.Forms.ComboBox
    Friend WithEvents txtMajor As System.Windows.Forms.TextBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents chkTransfer As System.Windows.Forms.CheckBox
    Friend WithEvents txtGPA As System.Windows.Forms.TextBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents txtEnroll As System.Windows.Forms.MaskedTextBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents lblCollege As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents txtSAT As System.Windows.Forms.TextBox
    Friend WithEvents txtACT As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents txtGradYear As System.Windows.Forms.MaskedTextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnSubmit As System.Windows.Forms.Button
    Friend WithEvents lblStudentID As System.Windows.Forms.Label
    Friend WithEvents txtStudentID As System.Windows.Forms.TextBox
    Friend WithEvents OutreachDataSet As WindowsApp1.OutreachDataSet
    Friend WithEvents TblParentBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblParentTableAdapter As WindowsApp1.OutreachDataSetTableAdapters.tblParentTableAdapter
    Friend WithEvents ParentIDDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ParentFirstNameDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ParentLastNameDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AlumniDataGridViewCheckBoxColumn As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents TblHighSchoolBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblHighSchoolTableAdapter As WindowsApp1.OutreachDataSetTableAdapters.tblHighSchoolTableAdapter
    Friend WithEvents TblCollegeBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblCollegeTableAdapter As WindowsApp1.OutreachDataSetTableAdapters.tblCollegeTableAdapter
    Friend WithEvents lblSearchParent As System.Windows.Forms.Label
    Friend WithEvents btnSearchParent As System.Windows.Forms.Button
    Friend WithEvents txtParentLast As System.Windows.Forms.TextBox
    Friend WithEvents btnDisplayParents As System.Windows.Forms.Button
End Class
