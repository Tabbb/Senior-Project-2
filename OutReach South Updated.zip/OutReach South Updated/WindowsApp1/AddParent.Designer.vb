﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AddParent
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.chkAlumni = New System.Windows.Forms.CheckBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.txtParentLast = New System.Windows.Forms.TextBox()
        Me.txtParentFirst = New System.Windows.Forms.TextBox()
        Me.btnAddParent = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'chkAlumni
        '
        Me.chkAlumni.AutoSize = True
        Me.chkAlumni.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkAlumni.Location = New System.Drawing.Point(609, 43)
        Me.chkAlumni.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.chkAlumni.Name = "chkAlumni"
        Me.chkAlumni.Size = New System.Drawing.Size(94, 29)
        Me.chkAlumni.TabIndex = 2
        Me.chkAlumni.Text = "Alumni"
        Me.chkAlumni.UseVisualStyleBackColor = True
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(314, 48)
        Me.Label25.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(55, 25)
        Me.Label25.TabIndex = 56
        Me.Label25.Text = "Last:"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(28, 50)
        Me.Label24.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(55, 25)
        Me.Label24.TabIndex = 0
        Me.Label24.Text = "First:"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(16, 11)
        Me.Label23.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(170, 20)
        Me.Label23.TabIndex = 54
        Me.Label23.Text = "Parent Information:"
        '
        'txtParentLast
        '
        Me.txtParentLast.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtParentLast.Location = New System.Drawing.Point(377, 48)
        Me.txtParentLast.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtParentLast.Name = "txtParentLast"
        Me.txtParentLast.Size = New System.Drawing.Size(223, 24)
        Me.txtParentLast.TabIndex = 1
        '
        'txtParentFirst
        '
        Me.txtParentFirst.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtParentFirst.Location = New System.Drawing.Point(95, 49)
        Me.txtParentFirst.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtParentFirst.Name = "txtParentFirst"
        Me.txtParentFirst.Size = New System.Drawing.Size(211, 24)
        Me.txtParentFirst.TabIndex = 0
        '
        'btnAddParent
        '
        Me.btnAddParent.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAddParent.Location = New System.Drawing.Point(139, 94)
        Me.btnAddParent.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnAddParent.Name = "btnAddParent"
        Me.btnAddParent.Size = New System.Drawing.Size(168, 65)
        Me.btnAddParent.TabIndex = 3
        Me.btnAddParent.Text = "Add Parent "
        Me.btnAddParent.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClose.Location = New System.Drawing.Point(369, 94)
        Me.btnClose.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(168, 65)
        Me.btnClose.TabIndex = 4
        Me.btnClose.Text = "Close Form"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'AddParent
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(716, 174)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnAddParent)
        Me.Controls.Add(Me.chkAlumni)
        Me.Controls.Add(Me.Label25)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.txtParentLast)
        Me.Controls.Add(Me.txtParentFirst)
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Name = "AddParent"
        Me.Text = "Add Parent Form"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents chkAlumni As CheckBox
    Friend WithEvents Label25 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents txtParentLast As TextBox
    Friend WithEvents txtParentFirst As TextBox
    Friend WithEvents btnAddParent As Button
    Friend WithEvents btnClose As Button
End Class
