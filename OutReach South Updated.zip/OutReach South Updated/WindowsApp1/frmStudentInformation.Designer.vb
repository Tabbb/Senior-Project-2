﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmStudentInformation
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btnSubmit = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtStudentFirst = New System.Windows.Forms.TextBox()
        Me.txtStudentMiddle = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtStreet = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtCity = New System.Windows.Forms.TextBox()
        Me.txtZip = New System.Windows.Forms.MaskedTextBox()
        Me.cboState = New System.Windows.Forms.ComboBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtCell = New System.Windows.Forms.MaskedTextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.txtDOB = New System.Windows.Forms.MaskedTextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.txtGradYear = New System.Windows.Forms.MaskedTextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.txtACT = New System.Windows.Forms.TextBox()
        Me.txtSAT = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.lblCollege = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.txtEnroll = New System.Windows.Forms.MaskedTextBox()
        Me.txtStudentLast = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.txtGPA = New System.Windows.Forms.TextBox()
        Me.chkTransfer = New System.Windows.Forms.CheckBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.txtMajor = New System.Windows.Forms.TextBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.txtHome = New System.Windows.Forms.MaskedTextBox()
        Me.cmbPhase = New System.Windows.Forms.ComboBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.radSummer = New System.Windows.Forms.RadioButton()
        Me.radFall = New System.Windows.Forms.RadioButton()
        Me.radSpring = New System.Windows.Forms.RadioButton()
        Me.cboClassification = New System.Windows.Forms.ComboBox()
        Me.lblClassification = New System.Windows.Forms.Label()
        Me.radMs = New System.Windows.Forms.RadioButton()
        Me.radMr = New System.Windows.Forms.RadioButton()
        Me.lblParent = New System.Windows.Forms.Label()
        Me.btnAddParent = New System.Windows.Forms.Button()
        Me.lblAddParent = New System.Windows.Forms.Label()
        Me.OutreachDataSet = New WindowsApp1.OutreachDataSet()
        Me.TblParentBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TblParentTableAdapter = New WindowsApp1.OutreachDataSetTableAdapters.tblParentTableAdapter()
        Me.dgvParents = New System.Windows.Forms.DataGridView()
        Me.btnUnselect = New System.Windows.Forms.Button()
        Me.cboHighSchool = New System.Windows.Forms.ComboBox()
        Me.TblHighSchoolBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.btnCreateHighSchool = New System.Windows.Forms.Button()
        Me.btnCreateCollege = New System.Windows.Forms.Button()
        Me.cboCollege = New System.Windows.Forms.ComboBox()
        Me.TblCollegeBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TblHighSchoolTableAdapter = New WindowsApp1.OutreachDataSetTableAdapters.tblHighSchoolTableAdapter()
        Me.TblCollegeTableAdapter = New WindowsApp1.OutreachDataSetTableAdapters.tblCollegeTableAdapter()
        Me.btnSearchParent = New System.Windows.Forms.Button()
        Me.txtParentLast = New System.Windows.Forms.TextBox()
        Me.lblSearchParent = New System.Windows.Forms.Label()
        Me.btnDisplayParents = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        CType(Me.OutreachDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblParentBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgvParents, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblHighSchoolBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblCollegeBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnSubmit
        '
        Me.btnSubmit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSubmit.Location = New System.Drawing.Point(932, 700)
        Me.btnSubmit.Margin = New System.Windows.Forms.Padding(4)
        Me.btnSubmit.Name = "btnSubmit"
        Me.btnSubmit.Size = New System.Drawing.Size(100, 42)
        Me.btnSubmit.TabIndex = 30
        Me.btnSubmit.Text = "Submit"
        Me.btnSubmit.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(13, 51)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(173, 20)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Student Information"
        '
        'txtStudentFirst
        '
        Me.txtStudentFirst.AcceptsTab = True
        Me.txtStudentFirst.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtStudentFirst.Location = New System.Drawing.Point(207, 97)
        Me.txtStudentFirst.Margin = New System.Windows.Forms.Padding(4)
        Me.txtStudentFirst.Name = "txtStudentFirst"
        Me.txtStudentFirst.Size = New System.Drawing.Size(216, 24)
        Me.txtStudentFirst.TabIndex = 2
        '
        'txtStudentMiddle
        '
        Me.txtStudentMiddle.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtStudentMiddle.Location = New System.Drawing.Point(515, 97)
        Me.txtStudentMiddle.Margin = New System.Windows.Forms.Padding(4)
        Me.txtStudentMiddle.Name = "txtStudentMiddle"
        Me.txtStudentMiddle.Size = New System.Drawing.Size(144, 24)
        Me.txtStudentMiddle.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(20, 74)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(79, 18)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Full Name:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(148, 100)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(51, 18)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "* First:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(448, 100)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(55, 18)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "Middle:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(686, 97)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(50, 18)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "* Last:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(13, 455)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(78, 20)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "Address"
        '
        'txtStreet
        '
        Me.txtStreet.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtStreet.Location = New System.Drawing.Point(100, 494)
        Me.txtStreet.Margin = New System.Windows.Forms.Padding(4)
        Me.txtStreet.Name = "txtStreet"
        Me.txtStreet.Size = New System.Drawing.Size(553, 24)
        Me.txtStreet.TabIndex = 9
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(33, 497)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(51, 18)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "Street:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(1088, 497)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(37, 18)
        Me.Label8.TabIndex = 14
        Me.Label8.Text = "City:"
        '
        'txtCity
        '
        Me.txtCity.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCity.Location = New System.Drawing.Point(1139, 494)
        Me.txtCity.Margin = New System.Windows.Forms.Padding(4)
        Me.txtCity.Name = "txtCity"
        Me.txtCity.Size = New System.Drawing.Size(176, 24)
        Me.txtCity.TabIndex = 12
        '
        'txtZip
        '
        Me.txtZip.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtZip.Location = New System.Drawing.Point(986, 495)
        Me.txtZip.Margin = New System.Windows.Forms.Padding(4)
        Me.txtZip.Mask = "00000"
        Me.txtZip.Name = "txtZip"
        Me.txtZip.Size = New System.Drawing.Size(77, 24)
        Me.txtZip.TabIndex = 11
        Me.txtZip.ValidatingType = GetType(Integer)
        '
        'cboState
        '
        Me.cboState.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboState.FormattingEnabled = True
        Me.cboState.Items.AddRange(New Object() {"Alabama ", "Alaska ", "Arizona ", "Arkansas ", "California ", "Colorado ", "Connecticut ", "Delaware ", "Florida ", "Georgia ", "Hawaii ", "Idaho ", "Illinois Indiana ", "Iowa ", "Kansas ", "Kentucky ", "Louisiana ", "Maine ", "Maryland ", "Massachusetts ", "Michigan ", "Minnesota ", "Mississippi ", "Missouri ", "Montana Nebraska ", "Nevada ", "New Hampshire ", "New Jersey ", "New Mexico ", "New York ", "North Carolina ", "North Dakota ", "Ohio ", "Oklahoma ", "Oregon ", "Pennsylvania Rhode Island ", "South Carolina ", "South Dakota ", "Tennessee ", "Texas ", "Utah ", "Vermont ", "Virginia ", "Washington ", "West Virginia ", "Wisconsin ", "Wyoming"})
        Me.cboState.Location = New System.Drawing.Point(731, 492)
        Me.cboState.Margin = New System.Windows.Forms.Padding(4)
        Me.cboState.Name = "cboState"
        Me.cboState.Size = New System.Drawing.Size(192, 26)
        Me.cboState.TabIndex = 10
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(670, 496)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(46, 18)
        Me.Label9.TabIndex = 18
        Me.Label9.Text = "State:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(946, 497)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(32, 18)
        Me.Label10.TabIndex = 19
        Me.Label10.Text = "Zip:"
        '
        'txtCell
        '
        Me.txtCell.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCell.Location = New System.Drawing.Point(778, 136)
        Me.txtCell.Margin = New System.Windows.Forms.Padding(4)
        Me.txtCell.Mask = "(999) 000-0000"
        Me.txtCell.Name = "txtCell"
        Me.txtCell.Size = New System.Drawing.Size(145, 24)
        Me.txtCell.TabIndex = 7
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(672, 142)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(94, 18)
        Me.Label11.TabIndex = 21
        Me.Label11.Text = "Cell Number:"
        '
        'btnClear
        '
        Me.btnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.Location = New System.Drawing.Point(1056, 700)
        Me.btnClear.Margin = New System.Windows.Forms.Padding(4)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(100, 42)
        Me.btnClear.TabIndex = 31
        Me.btnClear.Text = "Clear All"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'txtEmail
        '
        Me.txtEmail.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEmail.Location = New System.Drawing.Point(374, 136)
        Me.txtEmail.Margin = New System.Windows.Forms.Padding(4)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(275, 24)
        Me.txtEmail.TabIndex = 6
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(297, 139)
        Me.Label12.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(59, 18)
        Me.Label12.TabIndex = 24
        Me.Label12.Text = "* Email:"
        '
        'txtDOB
        '
        Me.txtDOB.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDOB.Location = New System.Drawing.Point(151, 136)
        Me.txtDOB.Margin = New System.Windows.Forms.Padding(4)
        Me.txtDOB.Mask = "00/00/0000"
        Me.txtDOB.Name = "txtDOB"
        Me.txtDOB.Size = New System.Drawing.Size(112, 24)
        Me.txtDOB.TabIndex = 5
        Me.txtDOB.ValidatingType = GetType(Date)
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(24, 139)
        Me.Label13.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(104, 18)
        Me.Label13.TabIndex = 26
        Me.Label13.Text = "* Date of Birth:"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(13, 545)
        Me.Label14.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(92, 20)
        Me.Label14.TabIndex = 27
        Me.Label14.Text = "Education"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(43, 583)
        Me.Label15.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(93, 18)
        Me.Label15.TabIndex = 28
        Me.Label15.Text = "High School:"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(1026, 580)
        Me.Label16.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(129, 18)
        Me.Label16.TabIndex = 30
        Me.Label16.Text = "* Graduation Year:"
        '
        'txtGradYear
        '
        Me.txtGradYear.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtGradYear.Location = New System.Drawing.Point(1182, 577)
        Me.txtGradYear.Margin = New System.Windows.Forms.Padding(4)
        Me.txtGradYear.Mask = "####"
        Me.txtGradYear.Name = "txtGradYear"
        Me.txtGradYear.Size = New System.Drawing.Size(56, 24)
        Me.txtGradYear.TabIndex = 16
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(33, 665)
        Me.Label17.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(60, 18)
        Me.Label17.TabIndex = 32
        Me.Label17.Text = "Scores:"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(66, 697)
        Me.Label18.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(37, 18)
        Me.Label18.TabIndex = 33
        Me.Label18.Text = "ACT"
        '
        'txtACT
        '
        Me.txtACT.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtACT.Location = New System.Drawing.Point(116, 694)
        Me.txtACT.Margin = New System.Windows.Forms.Padding(4)
        Me.txtACT.MaxLength = 2
        Me.txtACT.Name = "txtACT"
        Me.txtACT.Size = New System.Drawing.Size(56, 24)
        Me.txtACT.TabIndex = 22
        '
        'txtSAT
        '
        Me.txtSAT.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSAT.Location = New System.Drawing.Point(116, 735)
        Me.txtSAT.Margin = New System.Windows.Forms.Padding(4)
        Me.txtSAT.MaxLength = 4
        Me.txtSAT.Name = "txtSAT"
        Me.txtSAT.Size = New System.Drawing.Size(56, 24)
        Me.txtSAT.TabIndex = 23
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(67, 738)
        Me.Label19.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(36, 18)
        Me.Label19.TabIndex = 39
        Me.Label19.Text = "SAT"
        '
        'lblCollege
        '
        Me.lblCollege.AutoSize = True
        Me.lblCollege.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCollege.Location = New System.Drawing.Point(13, 621)
        Me.lblCollege.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblCollege.Name = "lblCollege"
        Me.lblCollege.Size = New System.Drawing.Size(123, 18)
        Me.lblCollege.TabIndex = 40
        Me.lblCollege.Text = "College Attended:"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(542, 19)
        Me.Label21.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(239, 29)
        Me.Label21.TabIndex = 42
        Me.Label21.Text = "Student Information"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(267, 700)
        Me.Label22.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(265, 18)
        Me.Label22.TabIndex = 43
        Me.Label22.Text = "Year the student plans to enroll to USA:"
        '
        'txtEnroll
        '
        Me.txtEnroll.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEnroll.Location = New System.Drawing.Point(565, 697)
        Me.txtEnroll.Margin = New System.Windows.Forms.Padding(4)
        Me.txtEnroll.Mask = "####"
        Me.txtEnroll.Name = "txtEnroll"
        Me.txtEnroll.Size = New System.Drawing.Size(65, 24)
        Me.txtEnroll.TabIndex = 24
        '
        'txtStudentLast
        '
        Me.txtStudentLast.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtStudentLast.Location = New System.Drawing.Point(755, 94)
        Me.txtStudentLast.Margin = New System.Windows.Forms.Padding(4)
        Me.txtStudentLast.Name = "txtStudentLast"
        Me.txtStudentLast.Size = New System.Drawing.Size(247, 24)
        Me.txtStudentLast.TabIndex = 4
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(13, 175)
        Me.Label23.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(164, 20)
        Me.Label23.TabIndex = 48
        Me.Label23.Text = "Parent Information"
        '
        'btnClose
        '
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClose.Location = New System.Drawing.Point(1182, 700)
        Me.btnClose.Margin = New System.Windows.Forms.Padding(4)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(100, 42)
        Me.btnClose.TabIndex = 32
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(851, 621)
        Me.Label26.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(118, 18)
        Me.Label26.TabIndex = 53
        Me.Label26.Text = "GPA (4.0 Scale):"
        '
        'txtGPA
        '
        Me.txtGPA.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtGPA.Location = New System.Drawing.Point(977, 618)
        Me.txtGPA.Margin = New System.Windows.Forms.Padding(4)
        Me.txtGPA.MaxLength = 4
        Me.txtGPA.Name = "txtGPA"
        Me.txtGPA.Size = New System.Drawing.Size(61, 24)
        Me.txtGPA.TabIndex = 20
        '
        'chkTransfer
        '
        Me.chkTransfer.AutoSize = True
        Me.chkTransfer.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkTransfer.Location = New System.Drawing.Point(695, 620)
        Me.chkTransfer.Margin = New System.Windows.Forms.Padding(4)
        Me.chkTransfer.Name = "chkTransfer"
        Me.chkTransfer.Size = New System.Drawing.Size(131, 22)
        Me.chkTransfer.TabIndex = 19
        Me.chkTransfer.Text = "Tranfer Student"
        Me.chkTransfer.UseVisualStyleBackColor = True
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(1066, 623)
        Me.Label27.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(50, 18)
        Me.Label27.TabIndex = 56
        Me.Label27.Text = "Major:"
        '
        'txtMajor
        '
        Me.txtMajor.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMajor.Location = New System.Drawing.Point(1124, 618)
        Me.txtMajor.Margin = New System.Windows.Forms.Padding(4)
        Me.txtMajor.Name = "txtMajor"
        Me.txtMajor.Size = New System.Drawing.Size(191, 24)
        Me.txtMajor.TabIndex = 21
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(953, 139)
        Me.Label28.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(110, 18)
        Me.Label28.TabIndex = 58
        Me.Label28.Text = "Home Number:"
        '
        'txtHome
        '
        Me.txtHome.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtHome.Location = New System.Drawing.Point(1073, 136)
        Me.txtHome.Margin = New System.Windows.Forms.Padding(4)
        Me.txtHome.Mask = "(999) 000-0000"
        Me.txtHome.Name = "txtHome"
        Me.txtHome.Size = New System.Drawing.Size(153, 24)
        Me.txtHome.TabIndex = 8
        '
        'cmbPhase
        '
        Me.cmbPhase.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbPhase.FormattingEnabled = True
        Me.cmbPhase.Items.AddRange(New Object() {"Initial Meeting", "Email", "Mail ", "Phone Call"})
        Me.cmbPhase.Location = New System.Drawing.Point(244, 795)
        Me.cmbPhase.Margin = New System.Windows.Forms.Padding(4)
        Me.cmbPhase.Name = "cmbPhase"
        Me.cmbPhase.Size = New System.Drawing.Size(218, 26)
        Me.cmbPhase.TabIndex = 29
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(67, 798)
        Me.Label29.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(137, 18)
        Me.Label29.TabIndex = 61
        Me.Label29.Text = "* Phase of Contact:"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(13, 778)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(61, 20)
        Me.Label30.TabIndex = 62
        Me.Label30.Text = "Phase"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.radSummer)
        Me.GroupBox1.Controls.Add(Me.radFall)
        Me.GroupBox1.Controls.Add(Me.radSpring)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(661, 697)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(225, 114)
        Me.GroupBox1.TabIndex = 25
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Semester"
        '
        'radSummer
        '
        Me.radSummer.AutoSize = True
        Me.radSummer.Location = New System.Drawing.Point(28, 79)
        Me.radSummer.Name = "radSummer"
        Me.radSummer.Size = New System.Drawing.Size(132, 22)
        Me.radSummer.TabIndex = 28
        Me.radSummer.TabStop = True
        Me.radSummer.Text = "Summer (June)"
        Me.radSummer.UseVisualStyleBackColor = True
        '
        'radFall
        '
        Me.radFall.AutoSize = True
        Me.radFall.Location = New System.Drawing.Point(28, 51)
        Me.radFall.Name = "radFall"
        Me.radFall.Size = New System.Drawing.Size(111, 22)
        Me.radFall.TabIndex = 27
        Me.radFall.TabStop = True
        Me.radFall.Text = "Fall (August)"
        Me.radFall.UseVisualStyleBackColor = True
        '
        'radSpring
        '
        Me.radSpring.AutoSize = True
        Me.radSpring.Location = New System.Drawing.Point(28, 23)
        Me.radSpring.Name = "radSpring"
        Me.radSpring.Size = New System.Drawing.Size(137, 22)
        Me.radSpring.TabIndex = 26
        Me.radSpring.TabStop = True
        Me.radSpring.Text = "Spring (January)"
        Me.radSpring.UseVisualStyleBackColor = True
        '
        'cboClassification
        '
        Me.cboClassification.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboClassification.FormattingEnabled = True
        Me.cboClassification.Items.AddRange(New Object() {"Junior", "Senior"})
        Me.cboClassification.Location = New System.Drawing.Point(830, 577)
        Me.cboClassification.Name = "cboClassification"
        Me.cboClassification.Size = New System.Drawing.Size(187, 26)
        Me.cboClassification.TabIndex = 15
        '
        'lblClassification
        '
        Me.lblClassification.AutoSize = True
        Me.lblClassification.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblClassification.Location = New System.Drawing.Point(713, 580)
        Me.lblClassification.Name = "lblClassification"
        Me.lblClassification.Size = New System.Drawing.Size(100, 18)
        Me.lblClassification.TabIndex = 65
        Me.lblClassification.Text = "Classification:"
        '
        'radMs
        '
        Me.radMs.AutoSize = True
        Me.radMs.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radMs.Location = New System.Drawing.Point(33, 100)
        Me.radMs.Name = "radMs"
        Me.radMs.Size = New System.Drawing.Size(50, 22)
        Me.radMs.TabIndex = 0
        Me.radMs.TabStop = True
        Me.radMs.Text = "Ms"
        Me.radMs.UseVisualStyleBackColor = True
        '
        'radMr
        '
        Me.radMr.AutoSize = True
        Me.radMr.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radMr.Location = New System.Drawing.Point(89, 100)
        Me.radMr.Name = "radMr"
        Me.radMr.Size = New System.Drawing.Size(47, 22)
        Me.radMr.TabIndex = 1
        Me.radMr.TabStop = True
        Me.radMr.Text = "Mr"
        Me.radMr.UseVisualStyleBackColor = True
        '
        'lblParent
        '
        Me.lblParent.AutoSize = True
        Me.lblParent.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblParent.Location = New System.Drawing.Point(33, 209)
        Me.lblParent.Name = "lblParent"
        Me.lblParent.Size = New System.Drawing.Size(157, 18)
        Me.lblParent.TabIndex = 67
        Me.lblParent.Text = "Please select a parent:"
        '
        'btnAddParent
        '
        Me.btnAddParent.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAddParent.Location = New System.Drawing.Point(918, 363)
        Me.btnAddParent.Margin = New System.Windows.Forms.Padding(4)
        Me.btnAddParent.Name = "btnAddParent"
        Me.btnAddParent.Size = New System.Drawing.Size(145, 37)
        Me.btnAddParent.TabIndex = 36
        Me.btnAddParent.Text = "Add Parent"
        Me.btnAddParent.UseVisualStyleBackColor = True
        '
        'lblAddParent
        '
        Me.lblAddParent.AutoSize = True
        Me.lblAddParent.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAddParent.Location = New System.Drawing.Point(676, 364)
        Me.lblAddParent.Name = "lblAddParent"
        Me.lblAddParent.Size = New System.Drawing.Size(213, 36)
        Me.lblAddParent.TabIndex = 69
        Me.lblAddParent.Text = "If parent does not exist, " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "select to add a new parent here"
        '
        'OutreachDataSet
        '
        Me.OutreachDataSet.DataSetName = "OutreachDataSet"
        Me.OutreachDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TblParentBindingSource
        '
        Me.TblParentBindingSource.DataMember = "tblParent"
        Me.TblParentBindingSource.DataSource = Me.OutreachDataSet
        '
        'TblParentTableAdapter
        '
        Me.TblParentTableAdapter.ClearBeforeFill = True
        '
        'dgvParents
        '
        Me.dgvParents.AllowUserToAddRows = False
        Me.dgvParents.AllowUserToDeleteRows = False
        Me.dgvParents.AllowUserToOrderColumns = True
        Me.dgvParents.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvParents.Location = New System.Drawing.Point(35, 244)
        Me.dgvParents.Name = "dgvParents"
        Me.dgvParents.ReadOnly = True
        Me.dgvParents.RowTemplate.Height = 24
        Me.dgvParents.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvParents.Size = New System.Drawing.Size(624, 199)
        Me.dgvParents.TabIndex = 70
        '
        'btnUnselect
        '
        Me.btnUnselect.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUnselect.Location = New System.Drawing.Point(465, 200)
        Me.btnUnselect.Margin = New System.Windows.Forms.Padding(4)
        Me.btnUnselect.Name = "btnUnselect"
        Me.btnUnselect.Size = New System.Drawing.Size(194, 37)
        Me.btnUnselect.TabIndex = 33
        Me.btnUnselect.Text = "Unselect Parent"
        Me.btnUnselect.UseVisualStyleBackColor = True
        '
        'cboHighSchool
        '
        Me.cboHighSchool.DataSource = Me.TblHighSchoolBindingSource
        Me.cboHighSchool.DisplayMember = "HighSchoolName"
        Me.cboHighSchool.FormattingEnabled = True
        Me.cboHighSchool.Location = New System.Drawing.Point(160, 579)
        Me.cboHighSchool.Name = "cboHighSchool"
        Me.cboHighSchool.Size = New System.Drawing.Size(260, 24)
        Me.cboHighSchool.TabIndex = 13
        Me.cboHighSchool.ValueMember = "HighSchoolID"
        '
        'TblHighSchoolBindingSource
        '
        Me.TblHighSchoolBindingSource.DataMember = "tblHighSchool"
        Me.TblHighSchoolBindingSource.DataSource = Me.OutreachDataSet
        '
        'btnCreateHighSchool
        '
        Me.btnCreateHighSchool.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCreateHighSchool.Location = New System.Drawing.Point(435, 575)
        Me.btnCreateHighSchool.Margin = New System.Windows.Forms.Padding(4)
        Me.btnCreateHighSchool.Name = "btnCreateHighSchool"
        Me.btnCreateHighSchool.Size = New System.Drawing.Size(214, 28)
        Me.btnCreateHighSchool.TabIndex = 14
        Me.btnCreateHighSchool.Text = "Create High School"
        Me.btnCreateHighSchool.UseVisualStyleBackColor = True
        '
        'btnCreateCollege
        '
        Me.btnCreateCollege.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCreateCollege.Location = New System.Drawing.Point(435, 618)
        Me.btnCreateCollege.Margin = New System.Windows.Forms.Padding(4)
        Me.btnCreateCollege.Name = "btnCreateCollege"
        Me.btnCreateCollege.Size = New System.Drawing.Size(214, 28)
        Me.btnCreateCollege.TabIndex = 18
        Me.btnCreateCollege.Text = "Create College"
        Me.btnCreateCollege.UseVisualStyleBackColor = True
        '
        'cboCollege
        '
        Me.cboCollege.DataSource = Me.TblCollegeBindingSource
        Me.cboCollege.DisplayMember = "CollegeName"
        Me.cboCollege.FormattingEnabled = True
        Me.cboCollege.Location = New System.Drawing.Point(160, 620)
        Me.cboCollege.Name = "cboCollege"
        Me.cboCollege.Size = New System.Drawing.Size(260, 24)
        Me.cboCollege.TabIndex = 17
        Me.cboCollege.ValueMember = "CollegeID"
        '
        'TblCollegeBindingSource
        '
        Me.TblCollegeBindingSource.DataMember = "tblCollege"
        Me.TblCollegeBindingSource.DataSource = Me.OutreachDataSet
        '
        'TblHighSchoolTableAdapter
        '
        Me.TblHighSchoolTableAdapter.ClearBeforeFill = True
        '
        'TblCollegeTableAdapter
        '
        Me.TblCollegeTableAdapter.ClearBeforeFill = True
        '
        'btnSearchParent
        '
        Me.btnSearchParent.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSearchParent.Location = New System.Drawing.Point(881, 289)
        Me.btnSearchParent.Margin = New System.Windows.Forms.Padding(4)
        Me.btnSearchParent.Name = "btnSearchParent"
        Me.btnSearchParent.Size = New System.Drawing.Size(235, 38)
        Me.btnSearchParent.TabIndex = 35
        Me.btnSearchParent.Text = "Search for a Parent"
        Me.btnSearchParent.UseVisualStyleBackColor = True
        '
        'txtParentLast
        '
        Me.txtParentLast.Location = New System.Drawing.Point(935, 260)
        Me.txtParentLast.Name = "txtParentLast"
        Me.txtParentLast.Size = New System.Drawing.Size(181, 22)
        Me.txtParentLast.TabIndex = 34
        '
        'lblSearchParent
        '
        Me.lblSearchParent.AutoSize = True
        Me.lblSearchParent.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSearchParent.Location = New System.Drawing.Point(676, 261)
        Me.lblSearchParent.Name = "lblSearchParent"
        Me.lblSearchParent.Size = New System.Drawing.Size(225, 18)
        Me.lblSearchParent.TabIndex = 71
        Me.lblSearchParent.Text = "Search for a parent by last name:"
        '
        'btnDisplayParents
        '
        Me.btnDisplayParents.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDisplayParents.Location = New System.Drawing.Point(234, 200)
        Me.btnDisplayParents.Margin = New System.Windows.Forms.Padding(4)
        Me.btnDisplayParents.Name = "btnDisplayParents"
        Me.btnDisplayParents.Size = New System.Drawing.Size(223, 37)
        Me.btnDisplayParents.TabIndex = 72
        Me.btnDisplayParents.Text = "Display All Parents"
        Me.btnDisplayParents.UseVisualStyleBackColor = True
        '
        'frmStudentInformation
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1328, 861)
        Me.Controls.Add(Me.btnDisplayParents)
        Me.Controls.Add(Me.cboCollege)
        Me.Controls.Add(Me.btnCreateCollege)
        Me.Controls.Add(Me.btnCreateHighSchool)
        Me.Controls.Add(Me.cboHighSchool)
        Me.Controls.Add(Me.btnUnselect)
        Me.Controls.Add(Me.btnSearchParent)
        Me.Controls.Add(Me.txtParentLast)
        Me.Controls.Add(Me.lblSearchParent)
        Me.Controls.Add(Me.dgvParents)
        Me.Controls.Add(Me.lblAddParent)
        Me.Controls.Add(Me.btnAddParent)
        Me.Controls.Add(Me.lblParent)
        Me.Controls.Add(Me.radMr)
        Me.Controls.Add(Me.radMs)
        Me.Controls.Add(Me.lblClassification)
        Me.Controls.Add(Me.cboClassification)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label30)
        Me.Controls.Add(Me.Label29)
        Me.Controls.Add(Me.cmbPhase)
        Me.Controls.Add(Me.txtHome)
        Me.Controls.Add(Me.Label28)
        Me.Controls.Add(Me.txtMajor)
        Me.Controls.Add(Me.Label27)
        Me.Controls.Add(Me.chkTransfer)
        Me.Controls.Add(Me.txtGPA)
        Me.Controls.Add(Me.Label26)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.txtStudentLast)
        Me.Controls.Add(Me.txtEnroll)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.lblCollege)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.txtSAT)
        Me.Controls.Add(Me.txtACT)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.txtGradYear)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.txtDOB)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.txtEmail)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.txtCell)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.cboState)
        Me.Controls.Add(Me.txtZip)
        Me.Controls.Add(Me.txtCity)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.txtStreet)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtStudentMiddle)
        Me.Controls.Add(Me.txtStudentFirst)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnSubmit)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frmStudentInformation"
        Me.Text = "Student Information"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.OutreachDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblParentBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgvParents, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblHighSchoolBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblCollegeBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnSubmit As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents txtStudentFirst As TextBox
    Friend WithEvents txtStudentMiddle As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents txtStreet As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents txtCity As TextBox
    Friend WithEvents txtZip As MaskedTextBox
    Friend WithEvents cboState As ComboBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents txtCell As MaskedTextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents btnClear As Button
    Friend WithEvents txtEmail As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents txtDOB As MaskedTextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents txtGradYear As MaskedTextBox
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents txtACT As TextBox
    Friend WithEvents txtSAT As TextBox
    Friend WithEvents Label19 As Label
    Friend WithEvents lblCollege As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents txtEnroll As MaskedTextBox
    Friend WithEvents txtStudentLast As TextBox
    Friend WithEvents Label23 As Label
    Friend WithEvents btnClose As Button
    Friend WithEvents Label26 As Label
    Friend WithEvents txtGPA As TextBox
    Friend WithEvents chkTransfer As CheckBox
    Friend WithEvents Label27 As Label
    Friend WithEvents txtMajor As TextBox
    Friend WithEvents Label28 As Label
    Friend WithEvents txtHome As MaskedTextBox
    Friend WithEvents cmbPhase As ComboBox
    Friend WithEvents Label29 As Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents cboClassification As System.Windows.Forms.ComboBox
    Friend WithEvents lblClassification As System.Windows.Forms.Label
    Friend WithEvents radMs As System.Windows.Forms.RadioButton
    Friend WithEvents radMr As System.Windows.Forms.RadioButton
    Friend WithEvents radSummer As System.Windows.Forms.RadioButton
    Friend WithEvents radFall As System.Windows.Forms.RadioButton
    Friend WithEvents radSpring As System.Windows.Forms.RadioButton
    Friend WithEvents lblParent As System.Windows.Forms.Label
    Friend WithEvents btnAddParent As System.Windows.Forms.Button
    Friend WithEvents lblAddParent As System.Windows.Forms.Label
    Friend WithEvents OutreachDataSet As WindowsApp1.OutreachDataSet
    Friend WithEvents TblParentBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblParentTableAdapter As WindowsApp1.OutreachDataSetTableAdapters.tblParentTableAdapter
    Friend WithEvents dgvParents As System.Windows.Forms.DataGridView
    Friend WithEvents btnUnselect As System.Windows.Forms.Button
    Friend WithEvents cboHighSchool As System.Windows.Forms.ComboBox
    Friend WithEvents btnCreateHighSchool As System.Windows.Forms.Button
    Friend WithEvents btnCreateCollege As System.Windows.Forms.Button
    Friend WithEvents cboCollege As System.Windows.Forms.ComboBox
    Friend WithEvents TblHighSchoolBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblHighSchoolTableAdapter As WindowsApp1.OutreachDataSetTableAdapters.tblHighSchoolTableAdapter
    Friend WithEvents TblCollegeBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblCollegeTableAdapter As WindowsApp1.OutreachDataSetTableAdapters.tblCollegeTableAdapter
    Friend WithEvents btnSearchParent As System.Windows.Forms.Button
    Friend WithEvents txtParentLast As System.Windows.Forms.TextBox
    Friend WithEvents lblSearchParent As System.Windows.Forms.Label
    Friend WithEvents btnDisplayParents As System.Windows.Forms.Button
End Class
