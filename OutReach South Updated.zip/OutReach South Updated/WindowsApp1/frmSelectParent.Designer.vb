﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSelectParent
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.dgvParents = New System.Windows.Forms.DataGridView()
        Me.lblParentInstruction = New System.Windows.Forms.Label()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.btnSubmit = New System.Windows.Forms.Button()
        CType(Me.dgvParents, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dgvParents
        '
        Me.dgvParents.AllowUserToAddRows = False
        Me.dgvParents.AllowUserToDeleteRows = False
        Me.dgvParents.AllowUserToOrderColumns = True
        Me.dgvParents.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvParents.Location = New System.Drawing.Point(32, 54)
        Me.dgvParents.Name = "dgvParents"
        Me.dgvParents.ReadOnly = True
        Me.dgvParents.RowTemplate.Height = 24
        Me.dgvParents.Size = New System.Drawing.Size(514, 194)
        Me.dgvParents.TabIndex = 0
        '
        'lblParentInstruction
        '
        Me.lblParentInstruction.AutoSize = True
        Me.lblParentInstruction.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblParentInstruction.Location = New System.Drawing.Point(29, 20)
        Me.lblParentInstruction.Name = "lblParentInstruction"
        Me.lblParentInstruction.Size = New System.Drawing.Size(368, 18)
        Me.lblParentInstruction.TabIndex = 1
        Me.lblParentInstruction.Text = "Please select the parent of the student and click submit"
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(102, 268)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(150, 47)
        Me.btnClose.TabIndex = 2
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'btnSubmit
        '
        Me.btnSubmit.Location = New System.Drawing.Point(318, 268)
        Me.btnSubmit.Name = "btnSubmit"
        Me.btnSubmit.Size = New System.Drawing.Size(150, 47)
        Me.btnSubmit.TabIndex = 3
        Me.btnSubmit.Text = "Submit"
        Me.btnSubmit.UseVisualStyleBackColor = True
        '
        'frmSelectParent
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(589, 327)
        Me.Controls.Add(Me.btnSubmit)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.lblParentInstruction)
        Me.Controls.Add(Me.dgvParents)
        Me.Name = "frmSelectParent"
        Me.Text = "Select Parent"
        CType(Me.dgvParents, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents dgvParents As System.Windows.Forms.DataGridView
    Friend WithEvents lblParentInstruction As System.Windows.Forms.Label
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents btnSubmit As System.Windows.Forms.Button
End Class
