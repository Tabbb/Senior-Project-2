﻿Public Class AddCollege
    Dim theCollege As New College

    Private Sub btnAddCollege_Click(sender As Object, e As EventArgs) Handles btnAddCollege.Click
        If dataok() Then
            Dim collegeName As String = txtCollege.Text
            Try
                theCollege.AddCollege(collegeName)
                MessageBox.Show("College successfully added.")
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
            Me.Close()
        End If
    End Sub

    Function dataok()
        If txtCollege.Text = "" Then
            MessageBox.Show("Please enter a college name.")
            txtCollege.Focus()
            Return False
        Else
            Return True
        End If
    End Function

    Private Sub btnCloseForm_Click(sender As Object, e As EventArgs) Handles btnCloseForm.Click
        Me.Close()
    End Sub
End Class