﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmStudentDisplay
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtLastName = New System.Windows.Forms.TextBox()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.dgvResults = New System.Windows.Forms.DataGridView()
        Me.Results = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.radAll = New System.Windows.Forms.RadioButton()
        Me.radTransfer = New System.Windows.Forms.RadioButton()
        Me.radSenior = New System.Windows.Forms.RadioButton()
        Me.radJunior = New System.Windows.Forms.RadioButton()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.cboHighSchool = New System.Windows.Forms.ComboBox()
        Me.TblHighSchoolBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.OutreachDataSet = New WindowsApp1.OutreachDataSet()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.lblSearch = New System.Windows.Forms.Label()
        Me.cboCollege = New System.Windows.Forms.ComboBox()
        Me.TblCollegeBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btnEdit = New System.Windows.Forms.Button()
        Me.TblHighSchoolTableAdapter = New WindowsApp1.OutreachDataSetTableAdapters.tblHighSchoolTableAdapter()
        Me.TblCollegeTableAdapter = New WindowsApp1.OutreachDataSetTableAdapters.tblCollegeTableAdapter()
        Me.btnDisplayStudents = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cboPhase = New System.Windows.Forms.ComboBox()
        Me.TblStudentBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TblStudentTableAdapter = New WindowsApp1.OutreachDataSetTableAdapters.tblStudentTableAdapter()
        CType(Me.dgvResults, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        CType(Me.TblHighSchoolBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.OutreachDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblCollegeBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblStudentBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(29, 34)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(80, 17)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Last Name:"
        '
        'txtLastName
        '
        Me.txtLastName.Location = New System.Drawing.Point(126, 34)
        Me.txtLastName.Margin = New System.Windows.Forms.Padding(4)
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.Size = New System.Drawing.Size(149, 22)
        Me.txtLastName.TabIndex = 4
        '
        'btnSearch
        '
        Me.btnSearch.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSearch.Location = New System.Drawing.Point(291, 26)
        Me.btnSearch.Margin = New System.Windows.Forms.Padding(4)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(81, 37)
        Me.btnSearch.TabIndex = 6
        Me.btnSearch.Text = "Search"
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'dgvResults
        '
        Me.dgvResults.AllowUserToAddRows = False
        Me.dgvResults.AllowUserToDeleteRows = False
        Me.dgvResults.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvResults.Location = New System.Drawing.Point(13, 154)
        Me.dgvResults.Margin = New System.Windows.Forms.Padding(4)
        Me.dgvResults.Name = "dgvResults"
        Me.dgvResults.ReadOnly = True
        Me.dgvResults.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvResults.Size = New System.Drawing.Size(1122, 380)
        Me.dgvResults.TabIndex = 8
        '
        'Results
        '
        Me.Results.AutoSize = True
        Me.Results.Location = New System.Drawing.Point(13, 133)
        Me.Results.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Results.Name = "Results"
        Me.Results.Size = New System.Drawing.Size(55, 17)
        Me.Results.TabIndex = 9
        Me.Results.Text = "Results"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.radAll)
        Me.GroupBox1.Controls.Add(Me.radTransfer)
        Me.GroupBox1.Controls.Add(Me.radSenior)
        Me.GroupBox1.Controls.Add(Me.radJunior)
        Me.GroupBox1.Location = New System.Drawing.Point(380, 14)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox1.Size = New System.Drawing.Size(159, 133)
        Me.GroupBox1.TabIndex = 11
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Classification"
        '
        'radAll
        '
        Me.radAll.AutoSize = True
        Me.radAll.Location = New System.Drawing.Point(9, 19)
        Me.radAll.Margin = New System.Windows.Forms.Padding(4)
        Me.radAll.Name = "radAll"
        Me.radAll.Size = New System.Drawing.Size(44, 21)
        Me.radAll.TabIndex = 3
        Me.radAll.TabStop = True
        Me.radAll.Text = "All"
        Me.radAll.UseVisualStyleBackColor = True
        '
        'radTransfer
        '
        Me.radTransfer.AutoSize = True
        Me.radTransfer.Location = New System.Drawing.Point(9, 104)
        Me.radTransfer.Margin = New System.Windows.Forms.Padding(4)
        Me.radTransfer.Name = "radTransfer"
        Me.radTransfer.Size = New System.Drawing.Size(83, 21)
        Me.radTransfer.TabIndex = 2
        Me.radTransfer.TabStop = True
        Me.radTransfer.Text = "Transfer"
        Me.radTransfer.UseVisualStyleBackColor = True
        '
        'radSenior
        '
        Me.radSenior.AutoSize = True
        Me.radSenior.Location = New System.Drawing.Point(9, 77)
        Me.radSenior.Margin = New System.Windows.Forms.Padding(4)
        Me.radSenior.Name = "radSenior"
        Me.radSenior.Size = New System.Drawing.Size(70, 21)
        Me.radSenior.TabIndex = 1
        Me.radSenior.TabStop = True
        Me.radSenior.Text = "Senior"
        Me.radSenior.UseVisualStyleBackColor = True
        '
        'radJunior
        '
        Me.radJunior.AutoSize = True
        Me.radJunior.Location = New System.Drawing.Point(9, 48)
        Me.radJunior.Margin = New System.Windows.Forms.Padding(4)
        Me.radJunior.Name = "radJunior"
        Me.radJunior.Size = New System.Drawing.Size(68, 21)
        Me.radJunior.TabIndex = 0
        Me.radJunior.TabStop = True
        Me.radJunior.Text = "Junior"
        Me.radJunior.UseVisualStyleBackColor = True
        '
        'btnAdd
        '
        Me.btnAdd.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAdd.Location = New System.Drawing.Point(808, 18)
        Me.btnAdd.Margin = New System.Windows.Forms.Padding(4)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(160, 37)
        Me.btnAdd.TabIndex = 12
        Me.btnAdd.Text = "Add New Student"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'cboHighSchool
        '
        Me.cboHighSchool.DataSource = Me.TblHighSchoolBindingSource
        Me.cboHighSchool.DisplayMember = "HighSchoolName"
        Me.cboHighSchool.FormattingEnabled = True
        Me.cboHighSchool.Location = New System.Drawing.Point(547, 50)
        Me.cboHighSchool.Margin = New System.Windows.Forms.Padding(4)
        Me.cboHighSchool.Name = "cboHighSchool"
        Me.cboHighSchool.Size = New System.Drawing.Size(236, 24)
        Me.cboHighSchool.TabIndex = 13
        Me.cboHighSchool.ValueMember = "HighSchoolID"
        '
        'TblHighSchoolBindingSource
        '
        Me.TblHighSchoolBindingSource.DataMember = "tblHighSchool"
        Me.TblHighSchoolBindingSource.DataSource = Me.OutreachDataSet
        '
        'OutreachDataSet
        '
        Me.OutreachDataSet.DataSetName = "OutreachDataSet"
        Me.OutreachDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(544, 29)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(149, 17)
        Me.Label4.TabIndex = 14
        Me.Label4.Text = "High School Attended:"
        '
        'btnExit
        '
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(976, 61)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(4)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(160, 37)
        Me.btnExit.TabIndex = 15
        Me.btnExit.Text = "Exit Program"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnDelete
        '
        Me.btnDelete.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDelete.Location = New System.Drawing.Point(975, 18)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(160, 37)
        Me.btnDelete.TabIndex = 16
        Me.btnDelete.Text = "Delete Student"
        Me.btnDelete.UseVisualStyleBackColor = True
        '
        'lblSearch
        '
        Me.lblSearch.AutoSize = True
        Me.lblSearch.Location = New System.Drawing.Point(13, 13)
        Me.lblSearch.Name = "lblSearch"
        Me.lblSearch.Size = New System.Drawing.Size(127, 17)
        Me.lblSearch.TabIndex = 17
        Me.lblSearch.Text = "Search for Student"
        '
        'cboCollege
        '
        Me.cboCollege.DataSource = Me.TblCollegeBindingSource
        Me.cboCollege.DisplayMember = "CollegeName"
        Me.cboCollege.FormattingEnabled = True
        Me.cboCollege.Location = New System.Drawing.Point(547, 99)
        Me.cboCollege.Margin = New System.Windows.Forms.Padding(4)
        Me.cboCollege.Name = "cboCollege"
        Me.cboCollege.Size = New System.Drawing.Size(236, 24)
        Me.cboCollege.TabIndex = 18
        Me.cboCollege.ValueMember = "CollegeID"
        '
        'TblCollegeBindingSource
        '
        Me.TblCollegeBindingSource.DataMember = "tblCollege"
        Me.TblCollegeBindingSource.DataSource = Me.OutreachDataSet
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(544, 78)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(120, 17)
        Me.Label3.TabIndex = 19
        Me.Label3.Text = "College Attended:"
        '
        'btnEdit
        '
        Me.btnEdit.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEdit.Location = New System.Drawing.Point(808, 61)
        Me.btnEdit.Margin = New System.Windows.Forms.Padding(4)
        Me.btnEdit.Name = "btnEdit"
        Me.btnEdit.Size = New System.Drawing.Size(160, 37)
        Me.btnEdit.TabIndex = 20
        Me.btnEdit.Text = "Edit Student"
        Me.btnEdit.UseVisualStyleBackColor = True
        '
        'TblHighSchoolTableAdapter
        '
        Me.TblHighSchoolTableAdapter.ClearBeforeFill = True
        '
        'TblCollegeTableAdapter
        '
        Me.TblCollegeTableAdapter.ClearBeforeFill = True
        '
        'btnDisplayStudents
        '
        Me.btnDisplayStudents.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDisplayStudents.Location = New System.Drawing.Point(860, 106)
        Me.btnDisplayStudents.Margin = New System.Windows.Forms.Padding(4)
        Me.btnDisplayStudents.Name = "btnDisplayStudents"
        Me.btnDisplayStudents.Size = New System.Drawing.Size(218, 37)
        Me.btnDisplayStudents.TabIndex = 21
        Me.btnDisplayStudents.Text = "Display All Students"
        Me.btnDisplayStudents.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(57, 94)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(52, 17)
        Me.Label1.TabIndex = 22
        Me.Label1.Text = "Phase:"
        '
        'cboPhase
        '
        Me.cboPhase.FormattingEnabled = True
        Me.cboPhase.Items.AddRange(New Object() {"Initial Meeting", "Email", "Mail ", "Phone Call"})
        Me.cboPhase.Location = New System.Drawing.Point(126, 91)
        Me.cboPhase.Margin = New System.Windows.Forms.Padding(4)
        Me.cboPhase.Name = "cboPhase"
        Me.cboPhase.Size = New System.Drawing.Size(236, 24)
        Me.cboPhase.TabIndex = 23
        '
        'TblStudentBindingSource
        '
        Me.TblStudentBindingSource.DataMember = "tblStudent"
        Me.TblStudentBindingSource.DataSource = Me.OutreachDataSet
        '
        'TblStudentTableAdapter
        '
        Me.TblStudentTableAdapter.ClearBeforeFill = True
        '
        'frmStudentDisplay
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1148, 547)
        Me.Controls.Add(Me.cboPhase)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnDisplayStudents)
        Me.Controls.Add(Me.btnEdit)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.cboCollege)
        Me.Controls.Add(Me.lblSearch)
        Me.Controls.Add(Me.btnDelete)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.cboHighSchool)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Results)
        Me.Controls.Add(Me.dgvResults)
        Me.Controls.Add(Me.btnSearch)
        Me.Controls.Add(Me.txtLastName)
        Me.Controls.Add(Me.Label2)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frmStudentDisplay"
        Me.Text = "Outreach South"
        CType(Me.dgvResults, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.TblHighSchoolBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.OutreachDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblCollegeBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblStudentBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label2 As Label
    Friend WithEvents txtLastName As TextBox
    Friend WithEvents btnSearch As Button
    Friend WithEvents dgvResults As DataGridView
    Friend WithEvents Results As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents radTransfer As RadioButton
    Friend WithEvents radSenior As RadioButton
    Friend WithEvents radJunior As RadioButton
    Friend WithEvents btnAdd As Button
    Friend WithEvents cboHighSchool As ComboBox
    Friend WithEvents Label4 As Label
    Friend WithEvents btnExit As Button
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents lblSearch As System.Windows.Forms.Label
    Friend WithEvents radAll As System.Windows.Forms.RadioButton
    Friend WithEvents cboCollege As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents btnEdit As System.Windows.Forms.Button
    Friend WithEvents OutreachDataSet As WindowsApp1.OutreachDataSet
    Friend WithEvents TblHighSchoolBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblHighSchoolTableAdapter As WindowsApp1.OutreachDataSetTableAdapters.tblHighSchoolTableAdapter
    Friend WithEvents TblCollegeBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblCollegeTableAdapter As WindowsApp1.OutreachDataSetTableAdapters.tblCollegeTableAdapter
    Friend WithEvents btnDisplayStudents As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cboPhase As System.Windows.Forms.ComboBox
    Friend WithEvents TblStudentBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblStudentTableAdapter As WindowsApp1.OutreachDataSetTableAdapters.tblStudentTableAdapter
End Class
