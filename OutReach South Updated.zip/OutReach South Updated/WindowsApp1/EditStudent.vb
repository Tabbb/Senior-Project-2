﻿Public Class frmEditStudent
    Dim theStudent As New Student
    Dim theParent As New Parent
    Dim theHighSchool As New HighSchool
    Dim theCollege As New College
    Private Sub EditStudent_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'OutreachDataSet.tblCollege' table. You can move, or remove it, as needed.
        Me.TblCollegeTableAdapter.Fill(Me.OutreachDataSet.tblCollege)
        'TODO: This line of code loads data into the 'OutreachDataSet.tblHighSchool' table. You can move, or remove it, as needed.
        Me.TblHighSchoolTableAdapter.Fill(Me.OutreachDataSet.tblHighSchool)
        'TODO: This line of code loads data into the 'OutreachDataSet.tblParent' table. You can move, or remove it, as needed.
        Me.TblParentTableAdapter.Fill(Me.OutreachDataSet.tblParent)
        Dim dgvindex As Integer = frmStudentDisplay.dgvResults.CurrentRow.Index
        'studentID
        txtStudentID.Text = frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(0).Value
        'first name
        txtStudentFirst.Text = frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(1).Value
        'middle name
        txtStudentMiddle.Text = frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(2).Value
        'last name
        txtStudentLast.Text = frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(3).Value
        'gender
        If frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(4).Value = "Female" Then
            radMs.Checked = True
        ElseIf frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(4).Value = "Male" Then
            RadMr.Checked = True
        End If
        'street
        txtStreet.Text = frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(5).Value
        'city
        txtCity.Text = frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(6).Value
        'state
        Dim state As String = frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(7).Value
        If state <> "" Then
            Dim indexState As Integer = cboState.FindString(state)
            cboState.SelectedIndex = indexState
        End If
        'zip code
        txtZip.Text = frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(8).Value
        'home phone
        txtHome.Text = frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(9).Value
        'cell phone
        txtCell.Text = frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(10).Value
        'email
        txtEmail.Text = frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(11).Value
        'date of birth
        Dim strArrayDOB() As String
        If Not frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(12).Value Is Nothing Then
            strArrayDOB = CStr(frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(12).Value).Split("/"c)
            Dim month As String
            Dim day As String
            Dim year As String
            'this loop is used to change the date to ensure that it is in the correct format mm/dd/yyyy
            For count = 0 To strArrayDOB.Length - 1
                If count = 0 Then
                    If strArrayDOB(count).Length < 2 Then
                        month = "0" + CStr(strArrayDOB(count))
                    Else
                        month = CStr(strArrayDOB(count))
                    End If
                End If
                If count = 1 Then
                    If strArrayDOB(count).Length < 2 Then
                        day = "0" + CStr(strArrayDOB(count))
                    Else
                        day = CStr(strArrayDOB(count))
                    End If
                End If
                If count = 2 Then
                    year = CStr(strArrayDOB(count))
                End If
            Next
            Dim DOB As String = month + day + year
            txtDOB.Text = DOB
        End If
        'act score
        txtACT.Text = frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(13).Value
        'sat score
        txtSAT.Text = frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(14).Value
        'graduation year
        txtGradYear.Text = frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(15).Value
        'transfer student
        If frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(16).Value = True Then
            chkTransfer.Checked = True
        End If
        txtGPA.Text = frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(17).Value
        'enrollment date
        If frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(18).Value <> "" Then
            'split the value on the space (EX: Spring 2019)
            Dim strArray() As String
            strArray = frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(18).Value.split(" "c)
            For count = 0 To strArray.Length - 1
                If count = 1 Then
                    txtEnroll.Text = strArray(count)
                End If
                If count = 0 Then
                    If strArray(count) = "Spring" Then
                        radSpring.Checked = True
                    ElseIf strArray(count) = "Summer" Then
                        RadSummer.Checked = True
                    ElseIf strArray(count) = "Fall" Then
                        radFall.Checked = True
                    End If
                End If
            Next

        End If
        'classification
        If Not IsDBNull(frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(19).Value) Then
            Dim classification As String = frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(19).Value
            Dim indexClassification As Integer = cboClassification.FindString(classification)
            cboClassification.SelectedIndex = indexClassification
        End If
        'major
        If Not IsNothing(frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(20).Value) Then
            txtMajor.Text = frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(20).Value
        End If
        'phase
        If Not IsDBNull(frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(21).Value) Then
            Dim phase As String = frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(21).Value
            Dim indexPhase As Integer = cmbPhase.FindString(phase)
            cmbPhase.SelectedIndex = indexPhase
        End If
        'parent
        If Not IsDBNull(frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(22).Value) Then
            Dim parentID As Integer = frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(22).Value
            Dim currentrow As Integer
            For count = 0 To Me.dgvParents.RowCount - 1
                currentrow = Me.dgvParents.Rows(count).Cells(0).Value
                If Me.dgvParents.Rows(count).Cells(0).Value = parentID Then
                    dgvParents.CurrentCell = dgvParents.Rows(count).Cells(0)
                    Exit For
                End If
            Next
        Else
            dgvParents.ClearSelection()
        End If
        'highschool
        If Not IsDBNull(frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(23).Value) Then
            Dim highschool As String = frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(23).Value
            cboHighSchool.DataSource = theHighSchool.Highschool
            cboHighSchool.SelectedValue = highschool
        Else
            cboHighSchool.SelectedIndex = -1
        End If
        'college
        If Not IsDBNull(frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(24).Value) Then
            Dim college As String = frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(24).Value
            cboCollege.DataSource = theCollege.College
            cboCollege.SelectedValue = college
        Else
            cboCollege.SelectedIndex = -1
        End If
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs)
        Me.Close()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs)
        ' Clears form 
        Dim a As Control

        For Each a In Me.Controls
            If TypeOf a Is TextBox Then
                a.Text = Nothing
            End If
            If TypeOf a Is MaskedTextBox Then
                a.Text = Nothing
            End If
        Next
        chkTransfer.Checked = False
        cboState.SelectedIndex = -1
        cmbPhase.SelectedIndex = -1
        cboClassification.SelectedIndex = -1
        RadMr.Checked = False
        radMs.Checked = False
        radSpring.Checked = False
        RadSummer.Checked = False
        radFall.Checked = False
        txtStudentFirst.Focus()
    End Sub
    'Used to determine if required information is valid
    Function dataOk()
        'used to validate GPA
        Dim result As Double = 0.0
        If txtStudentFirst.Text = "" Then
            MessageBox.Show("PLease enter the first name.")
            Return False
        ElseIf txtStudentLast.Text = "" Then
            MessageBox.Show("Please enter the last name.")
            Return False
        ElseIf txtDOB.Text = "" Then
            MessageBox.Show("Please enter a valid date of birth.")
            Return False
        ElseIf txtEmail.Text = "" Then
            MessageBox.Show("Please enter an email address.")
            Return False
        ElseIf txtGradYear.Text = "" Or IsNumeric(txtGradYear.Text) = False Then
            MessageBox.Show("Please enter a valid graduation year.")
            Return False
        ElseIf cmbPhase.SelectedIndex = -1 Then
            MessageBox.Show("Please seleect a phase for the student.")
            Return False
        Else
            Return True
        End If
    End Function

    Private Sub btnAddParent_Click(sender As Object, e As EventArgs) Handles btnAddParent.Click
        AddParent.ShowDialog()
    End Sub

    Private Sub btnCreateHighSchool_Click(sender As Object, e As EventArgs) Handles btnCreateHighSchool.Click
        AddHighSchool.ShowDialog()
    End Sub

    Private Sub btnCreateCollege_Click(sender As Object, e As EventArgs) Handles btnCreateCollege.Click
        AddCollege.ShowDialog()
    End Sub

    Private Sub btnUnselect_Click(sender As Object, e As EventArgs) Handles btnUnselect.Click
        Me.dgvParents.ClearSelection()
    End Sub

    Private Sub btnClear_Click_1(sender As Object, e As EventArgs) Handles btnClear.Click
        ' Clears form 
        Dim a As Control

        For Each a In Me.Controls
            If TypeOf a Is TextBox Then
                a.Text = Nothing
            End If
            If TypeOf a Is MaskedTextBox Then
                a.Text = Nothing
            End If
        Next
        Dim dgvindex As Integer = frmStudentDisplay.dgvResults.CurrentRow.Index
        'studentID
        txtStudentID.Text = frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(0).Value
        chkTransfer.Checked = False
        cboState.SelectedIndex = -1
        cmbPhase.SelectedIndex = -1
        cboClassification.SelectedIndex = -1
        radMr.Checked = False
        radMs.Checked = False
        radSpring.Checked = False
        radSummer.Checked = False
        radFall.Checked = False
        cboCollege.SelectedIndex = -1
        cboHighSchool.SelectedIndex = -1
        Me.dgvParents.ClearSelection()
        txtStudentFirst.Focus()
    End Sub

    Private Sub btnClose_Click_1(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub btnSubmit_Click_1(sender As Object, e As EventArgs) Handles btnSubmit.Click
        'Determine if required information is valid
        If dataOk() Then
            'if the information is valid, get the inputted information from the user
            Dim StudentID As Integer = txtStudentID.Text
            Dim StudentFirst As String = txtStudentFirst.Text
            Dim StudentMiddle As String = txtStudentMiddle.Text
            Dim StudentLast As String = txtStudentLast.Text
            Dim Gender As String
            If radMs.Checked = True Then
                Gender = "Female"
            ElseIf radMr.Checked = True Then
                Gender = "Male"
            Else
                Gender = ""
            End If
            Dim DateOfBirth As String = txtDOB.Text
            Dim Street As String = txtStreet.Text
            Dim State As String
            If (String.IsNullOrEmpty(cboState.Text)) Then
                State = ""
            Else
                State = cboState.SelectedItem.ToString()
            End If
            Dim ZipCode As String = txtZip.Text
            Dim City As String = txtCity.Text
            Dim HomeNumber As String = txtHome.Text
            Dim CellNumber As String = txtCell.Text
            Dim TransferStudent As Boolean
            If chkTransfer.Checked = True Then
                TransferStudent = True
            Else
                TransferStudent = False
            End If
            Dim Email As String = txtEmail.Text
            Dim GraduationYear As String = txtGradYear.Text
            Dim EnrollmentYear As String = txtEnroll.Text
            If radFall.Checked = True And EnrollmentYear <> "" Then
                EnrollmentYear = "Fall " + EnrollmentYear
            ElseIf radSpring.Checked = True And EnrollmentYear <> "" Then
                EnrollmentYear = "Spring " + EnrollmentYear
            ElseIf radSummer.Checked = True And EnrollmentYear <> "" Then
                EnrollmentYear = "Summer " + EnrollmentYear
            End If
            Dim Classification As String
            If (String.IsNullOrEmpty(cboClassification.Text)) Then
                Classification = ""
            Else
                Classification = cboClassification.SelectedItem.ToString()
            End If
            Dim GPA As Double
            If txtGPA.Text = "" Then
                GPA = 0
            Else
                GPA = CDbl(txtGPA.Text)
            End If
            Dim Major As String = txtMajor.Text
            Dim phase As String = cmbPhase.SelectedItem.ToString()
            Dim ACTScore As Integer
            If txtACT.Text = "" Then
                ACTScore = 0
            Else
                ACTScore = CInt(txtACT.Text)
            End If
            Dim SATScore As Integer
            If txtSAT.Text = "" Then
                SATScore = 0
            Else
                SATScore = CInt(txtSAT.Text)
            End If
            Dim ParentID As Integer = 0
            If dgvParents.SelectedRows.Count > 0 Then
                Dim dgvindex As Integer = Me.dgvParents.CurrentRow.Index
                ParentID = Me.dgvParents.Rows(dgvindex).Cells(0).Value
            End If
            Dim CollegeID As Integer = 0
            If (String.IsNullOrEmpty(cboCollege.Text)) Then
                CollegeID = 0
            Else
                CollegeID = cboCollege.SelectedValue
            End If
            Dim HighSchoolID As Integer = 0
            If (String.IsNullOrEmpty(cboHighSchool.Text)) Then
                HighSchoolID = 0
            Else
                HighSchoolID = cboHighSchool.SelectedValue
            End If

            'create a new student record
            Try
                theStudent.update(StudentFirst, StudentMiddle, StudentLast, Gender, Street, City, State, ZipCode, HomeNumber, CellNumber, Email, DateOfBirth,
                                            ACTScore, SATScore, GraduationYear, TransferStudent, GPA, EnrollmentYear, Classification, Major, phase, ParentID, HighSchoolID, CollegeID, StudentID)
                MessageBox.Show("Student has successfully been updated.")
                ' Clears form 
                Dim a As Control

                For Each a In Me.Controls
                    If TypeOf a Is TextBox Then
                        a.Text = Nothing
                    End If
                    If TypeOf a Is MaskedTextBox Then
                        a.Text = Nothing
                    End If
                Next
                chkTransfer.Checked = False
                cboState.SelectedIndex = -1
                cmbPhase.SelectedIndex = -1
                cboClassification.SelectedIndex = -1
                radMr.Checked = False
                radMs.Checked = False
                radSpring.Checked = False
                radSummer.Checked = False
                radFall.Checked = False
                frmStudentDisplay.dgvResults.DataSource = theStudent.students
                Me.Close()
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try

        End If
    End Sub

    Private Sub btnDisplayParents_Click(sender As Object, e As EventArgs) Handles btnDisplayParents.Click
        dgvParents.DataSource = theParent.Parents
    End Sub

    Private Sub btnSearchParent_Click(sender As Object, e As EventArgs) Handles btnSearchParent.Click
        Dim parentLastName As String = txtParentLast.Text
        If searchok() Then
            Try
                theParent.findParent(parentLastName)
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
            dgvParents.DataSource = theParent.findParent(parentLastName)
        End If
    End Sub
    Function searchok()
        If txtParentLast.Text = "" Then
            MessageBox.Show("Please enter a parent last name to search for")
            Return False
        Else
            Return True
        End If
    End Function
End Class