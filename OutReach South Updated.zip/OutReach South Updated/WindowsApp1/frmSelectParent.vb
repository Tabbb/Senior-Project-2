﻿Public Class frmSelectParent
    Dim theParent As New Parent
    Private Sub frmSelectParent_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        dgvParents.DataSource = theParent.Parents
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Public Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        'get the selected row index
        Dim dgvindex As Integer = Me.dgvParents.CurrentRow.Index
        'get the parent ID from the selected parent row
        'Public parentID As Integer = Me.dgvParents.Rows(dgvindex).Cells(0).Value
        'close the dialog box
        Me.Close()
    End Sub
End Class