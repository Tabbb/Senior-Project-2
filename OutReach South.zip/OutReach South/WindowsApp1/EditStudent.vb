﻿Public Class frmEditStudent
    Private theStudent As New Student
    Private Sub EditStudent_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim dgvindex As Integer = frmStudentDisplay.dgvResults.CurrentRow.Index
        txtStudentFirst.Text = frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(1).Value
        txtStudentMiddle.Text = frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(2).Value
        txtStudentLast.Text = frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(3).Value
        If frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(4).Value = "Female" Then
            radMs.Checked = True
        ElseIf frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(4).Value = "Male" Then
            RadMr.Checked = True
        End If
        txtStreet.Text = frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(5).Value
        txtCity.Text = frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(6).Value
        'STATE
        Dim state = frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(7).Value
        If state <> "" Then
            Dim indexState As Integer = cboState.FindString(state)
            cboState.SelectedIndex = indexState
        End If
        'For i = 0 To cboState.Items.Count - 1
        'If cboState.Items.Item(i).ToString = state Then

        'End If
        'Next
        txtZip.Text = frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(8).Value
        txtHome.Text = frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(9).Value
        txtCell.Text = frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(10).Value
        txtEmail.Text = frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(11).Value
        txtDOB.Text = CDate(frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(12).Value)
        txtACT.Text = frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(13).Value
        txtSAT.Text = frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(14).Value
        txtGradYear.Text = frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(15).Value
        If frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(16).Value = True Then
            chkTransfer.Checked = True
        End If
        txtGPA.Text = frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(17).Value
        If frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(18).Value <> "" Then
            'split the value on the space (EX: Spring 2019)
            Dim strArray() As String
            strArray = frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(18).Value.split(" "c)
            For count = 0 To strArray.Length - 1
                If count = 1 Then
                    txtEnroll.Text = strArray(count)
                End If
                If count = 0 Then
                    If strArray(count) = "Spring" Then
                        radSpring.Checked = True
                    ElseIf strArray(count) = "Summer" Then
                        RadSummer.Checked = True
                    ElseIf strArray(count) = "Fall" Then
                        radFall.Checked = True
                    End If
                End If
            Next

        End If
        'classification
        'If frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(19).Value <> Null Then
        'txtMajor.Text = frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(19).Value
        'End If
        Dim phase As String = frmStudentDisplay.dgvResults.Rows(dgvindex).Cells(20).Value
        Dim index As Integer = cmbPhase.FindString(phase)
        cmbPhase.SelectedIndex = index



    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ' Clears form 
        Dim a As Control

        For Each a In Me.Controls
            If TypeOf a Is TextBox Then
                a.Text = Nothing
            End If
            If TypeOf a Is MaskedTextBox Then
                a.Text = Nothing
            End If
        Next
        chkAlumni.Checked = False
        chkTransfer.Checked = False
        cboState.SelectedIndex = -1
        cmbPhase.SelectedIndex = -1
        cboClassification.SelectedIndex = -1
        RadMr.Checked = False
        radMs.Checked = False
        radSpring.Checked = False
        RadSummer.Checked = False
        radFall.Checked = False
        txtStudentFirst.Focus()
    End Sub
End Class