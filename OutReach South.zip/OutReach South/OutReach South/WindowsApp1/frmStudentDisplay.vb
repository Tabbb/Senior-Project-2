﻿Public Class frmStudentDisplay
    Dim theStudent As New Student
    'Load the data grid view with the records from the student table
    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'OutreachDataSet.tblStudent' table. You can move, or remove it, as needed.
        Me.TblStudentTableAdapter.Fill(Me.OutreachDataSet.tblStudent)
        'TODO: This line of code loads data into the 'OutreachDataSet.tblCollege' table. You can move, or remove it, as needed.
        Me.TblCollegeTableAdapter.Fill(Me.OutreachDataSet.tblCollege)
        'TODO: This line of code loads data into the 'OutreachDataSet.tblHighSchool' table. You can move, or remove it, as needed.
        Me.TblHighSchoolTableAdapter.Fill(Me.OutreachDataSet.tblHighSchool)
        dgvResults.DataSource = theStudent.students
        Dim theHighSchools As New HighSchool
        Dim theColleges As New College
        cboCollege.SelectedIndex = -1
        cboHighSchool.SelectedIndex = -1
        cboPhase.SelectedIndex = -1

    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        frmStudentInformation.ShowDialog()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Dim result As Integer = MessageBox.Show("Are you sure you would like to delete this student record?", "Attention", MessageBoxButtons.YesNo)
        If result = DialogResult.Yes Then
            Try
                Dim idIndex As String
                'determines what student is selected
                idIndex = dgvResults.Item(0, dgvResults.CurrentRow.Index).Value
                'deletes the selected employee
                theStudent.delete(idIndex)
                'update the data grid view with the new set of students
                dgvResults.DataSource = theStudent.students
                MessageBox.Show("The selected student was deleted successfully.")
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
        End If
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        Dim StudentLastName As String = txtLastName.Text
        If dataok() Then
            Try
                theStudent.findLastName(StudentLastName)
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
            dgvResults.DataSource = theStudent.findLastName(StudentLastName)
        End If
    End Sub

    Private Sub radJunior_CheckedChanged(sender As Object, e As EventArgs) Handles radJunior.CheckedChanged
        Try
            theStudent.findClassification("Junior")
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
        dgvResults.DataSource = theStudent.findClassification("Junior")
    End Sub

    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click
        frmEditStudent.ShowDialog()
    End Sub
    Function dataok()
        If txtLastName.Text = "" Then
            MessageBox.Show("Please enter a last name to search by.")
            txtLastName.Focus()
            Return False
        Else
            Return True
        End If
    End Function

    Private Sub radSenior_CheckedChanged(sender As Object, e As EventArgs) Handles radSenior.CheckedChanged
        Try
            theStudent.findClassification("Senior")
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
        dgvResults.DataSource = theStudent.findClassification("Senior")
    End Sub

    Private Sub radTransfer_CheckedChanged(sender As Object, e As EventArgs) Handles radTransfer.CheckedChanged
        Try
            theStudent.findTransferStudents()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
        dgvResults.DataSource = theStudent.findTransferStudents()
    End Sub

    Private Sub radAll_CheckedChanged(sender As Object, e As EventArgs) Handles radAll.CheckedChanged
        dgvResults.DataSource = theStudent.students
    End Sub

    Private Sub btnDisplayStudents_Click(sender As Object, e As EventArgs) Handles btnDisplayStudents.Click
        dgvResults.DataSource = theStudent.students
        cboHighSchool.SelectedIndex = -1
        cboPhase.SelectedIndex = -1
        cboCollege.SelectedIndex = -1
        radAll.Checked = False
        radJunior.Checked = False
        radSenior.Checked = False
        radTransfer.Checked = False
        txtLastName.Text = ""
        txtLastName.Focus()
    End Sub

    Private Sub cboHighSchool_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboHighSchool.SelectedIndexChanged
        Dim HighSchool As String
        If Not (String.IsNullOrEmpty(cboHighSchool.Text)) Then
            HighSchool = cboHighSchool.SelectedValue
            Try
                theStudent.findCollege(HighSchool)
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
            dgvResults.DataSource = theStudent.findCollege(HighSchool)
            cboCollege.SelectedIndex = -1
            cboPhase.SelectedIndex = -1
        End If
    End Sub

    Private Sub cboCollege_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboCollege.SelectedIndexChanged
        Dim College As String
        If Not (String.IsNullOrEmpty(cboCollege.Text)) Then
            College = cboCollege.SelectedValue
            Try
                theStudent.findCollege(College)
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
            dgvResults.DataSource = theStudent.findCollege(College)
            cboHighSchool.SelectedIndex = -1
            cboPhase.SelectedIndex = -1
        End If

    End Sub

    Private Sub cboPhase_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboPhase.SelectedIndexChanged
        Dim Phase As String
        If Not (String.IsNullOrEmpty(cboPhase.Text)) Then
            Phase = cboPhase.SelectedItem
            Try
                theStudent.findPhase(Phase)
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
            dgvResults.DataSource = theStudent.findPhase(Phase)
            cboHighSchool.SelectedIndex = -1
            cboCollege.SelectedIndex = -1
        End If
    End Sub
End Class