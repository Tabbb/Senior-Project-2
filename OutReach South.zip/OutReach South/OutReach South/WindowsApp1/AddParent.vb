﻿Public Class AddParent
    Dim theParent As New Parent
    Dim theCollege As New College
    Private Sub btnAddParent_Click(sender As Object, e As EventArgs) Handles btnAddParent.Click
        If dataok() Then
            'get information from the form
            Dim firstName As String = txtParentFirst.Text
            Dim lastName As String = txtParentLast.Text
            Dim ParentAlumni As Boolean
            If chkAlumni.Checked = True Then
                ParentAlumni = True
            Else
                ParentAlumni = False
            End If

            Try
                firstName = firstName.Substring(0, 1).ToUpper() + firstName.Substring(1)
                lastName = lastName.Substring(0, 1).ToUpper() + lastName.Substring(1)
                theParent.insert(firstName, lastName, ParentAlumni)
                MessageBox.Show("Parent successfully added.")
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
            frmStudentInformation.dgvParents.DataSource = theParent.Parents
            frmEditStudent.dgvParents.DataSource = theParent.Parents
            txtParentFirst.Text = ""
            txtParentLast.Text = ""
            chkAlumni.Checked = False
            Me.Close()
        End If
    End Sub
    Function dataok()
        If txtParentFirst.Text = "" Then
            MessageBox.Show("Please enter a first name.")
            Return False
        ElseIf txtParentLast.Text = "" Then
            MessageBox.Show("Please enter a last name.")
            Return False
        Else
            Return True
        End If
    End Function

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        txtParentFirst.Text = ""
        txtParentLast.Text = ""
        chkAlumni.Checked = False
        Me.Close()
    End Sub
End Class