﻿Public Class AddHighSchool
    Dim theHighSchool As New HighSchool

    Private Sub btnAddHighSchool_Click(sender As Object, e As EventArgs) Handles btnAddHighSchool.Click
        If dataok() Then
            Dim HSname As String = txtHS.Text
            Try
                HSname = HSname.Substring(0, 1).ToUpper() + HSname.Substring(1)
                theHighSchool.AddHighschool(HSname)
                MessageBox.Show("Highschool successfully added.")
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
            txtHS.Text = ""
            Me.Close()
        End If
    End Sub

    Function dataok()
        If txtHS.Text = "" Then
            MessageBox.Show("Please enter a highschool name.")
            txtHS.Focus()
            Return False
        Else
            Return True
        End If
    End Function

    Private Sub btnCloseForm_Click(sender As Object, e As EventArgs) Handles btnCloseForm.Click
        txtHS.Text = ""
        Me.Close()
    End Sub
End Class