﻿Public Class frmStudentInformation
    Dim theStudent As New Student
    Dim theParent As New Parent
    Dim theHighSchool As New HighSchool
    Dim theCollege As New College

    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        'Determine if required information is valid
        If dataOk() Then
            'if the information is valid, get the inputted information from the user
            Dim StudentFirst As String = txtStudentFirst.Text
            Dim StudentMiddle As String = txtStudentMiddle.Text
            Dim StudentLast As String = txtStudentLast.Text
            Dim Gender As String
            If radMs.Checked = True Then
                Gender = "Female"
            ElseIf RadMr.Checked = True Then
                Gender = "Male"
            Else
                Gender = ""
            End If
            Dim DateOfBirth As String = txtDOB.Text
            Dim Street As String = txtStreet.Text
            Dim State As String
            If (String.IsNullOrEmpty(cboState.Text)) Then
                State = ""
            Else
                State = cboState.SelectedItem.ToString()
            End If
            Dim ZipCode As String = txtZip.Text
            Dim City As String = txtCity.Text
            Dim HomeNumber As String = txtHome.Text
            Dim CellNumber As String = txtCell.Text
            Dim TransferStudent As Boolean
            If chkTransfer.Checked = True Then
                TransferStudent = True
            Else
                TransferStudent = False
            End If
            Dim Email As String = txtEmail.Text
            Dim GraduationYear As String = txtGradYear.Text
            Dim EnrollmentYear As String = txtEnroll.Text
            If radFall.Checked = True And EnrollmentYear <> "" Then
                EnrollmentYear = "Fall " + EnrollmentYear
            ElseIf radSpring.Checked = True And EnrollmentYear <> "" Then
                EnrollmentYear = "Spring " + EnrollmentYear
            ElseIf RadSummer.Checked = True And EnrollmentYear <> "" Then
                EnrollmentYear = "Summer " + EnrollmentYear
            End If
            Dim Classification As String
            If (String.IsNullOrEmpty(cboClassification.Text)) Then
                Classification = ""
            Else
                Classification = cboClassification.SelectedItem.ToString()
            End If
            Dim GPA As Double
            If txtGPA.Text = "" Then
                GPA = 0
            Else
                GPA = CDbl(txtGPA.Text)
            End If
            Dim Major As String = txtMajor.Text
            Dim phase As String = cmbPhase.SelectedItem.ToString()
            Dim ACTScore As Integer
            If txtACT.Text = "" Then
                ACTScore = 0
            Else
                ACTScore = CInt(txtACT.Text)
            End If
            Dim SATScore As Integer
            If txtSAT.Text = "" Then
                SATScore = 0
            Else
                SATScore = CInt(txtSAT.Text)
            End If
            Dim ParentID As Integer = 0
            If dgvParents.SelectedRows.Count > 0 Then
                Dim dgvindex As Integer = Me.dgvParents.CurrentRow.Index
                ParentID = Me.dgvParents.Rows(dgvindex).Cells(0).Value
            End If
            Dim CollegeID As Integer = 0
            If (String.IsNullOrEmpty(cboCollege.Text)) Then
                CollegeID = 0
            Else
                CollegeID = cboCollege.SelectedValue
            End If
            Dim HighSchoolID As Integer = 0
            If (String.IsNullOrEmpty(cboHighSchool.Text)) Then
                HighSchoolID = 0
            Else
                HighSchoolID = cboHighSchool.SelectedValue
            End If

                'create a new student record
                Try
                    theStudent.insert(StudentFirst, StudentMiddle, StudentLast, Gender, Street, City, State, ZipCode, HomeNumber, CellNumber, Email, DateOfBirth,
                                            ACTScore, SATScore, GraduationYear, TransferStudent, GPA, EnrollmentYear, Classification, Major, phase, ParentID, HighSchoolID, CollegeID)
                    MessageBox.Show("Student has successfully been added.")
                    ' Clears form 
                    Dim a As Control

                    For Each a In Me.Controls
                        If TypeOf a Is TextBox Then
                            a.Text = Nothing
                        End If
                        If TypeOf a Is MaskedTextBox Then
                            a.Text = Nothing
                        End If
                    Next
                    chkTransfer.Checked = False
                    cboState.SelectedIndex = -1
                    cmbPhase.SelectedIndex = -1
                    cboClassification.SelectedIndex = -1
                    radMr.Checked = False
                    radMs.Checked = False
                    radSpring.Checked = False
                    radSummer.Checked = False
                radFall.Checked = False
                cboCollege.SelectedIndex = -1
                cboHighSchool.SelectedIndex = -1
                Me.dgvParents.ClearSelection()
                txtStudentFirst.Focus()
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
            frmStudentDisplay.dgvResults.DataSource = theStudent.students
        End If

    End Sub
    'Used to determine if required information is valid
    Function dataOk()
        'used to validate GPA
        Dim result As Double = 0.0
        If txtStudentFirst.Text = "" Then
            MessageBox.Show("PLease enter the first name.")
            Return False
        ElseIf txtStudentLast.Text = "" Then
            MessageBox.Show("Please enter the last name.")
            Return False
        ElseIf txtDOB.Text = "" Then
            MessageBox.Show("Please enter a valid date of birth.")
            Return False
        ElseIf txtEmail.Text = "" Then
            MessageBox.Show("Please enter an email address.")
            Return False
        ElseIf txtGradYear.Text = "" Or IsNumeric(txtGradYear.Text) = False Then
            MessageBox.Show("Please enter a valid graduation year.")
            Return False
        ElseIf cmbPhase.SelectedIndex = -1 Then
            MessageBox.Show("Please seleect a phase for the student.")
            Return False
        Else
            Return True
        End If
    End Function

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ' Clears form 
        Dim a As Control

        For Each a In Me.Controls
            If TypeOf a Is TextBox Then
                a.Text = Nothing
            End If
            If TypeOf a Is MaskedTextBox Then
                a.Text = Nothing
            End If
        Next
        chkTransfer.Checked = False
        cboState.SelectedIndex = -1
        cmbPhase.SelectedIndex = -1
        cboClassification.SelectedIndex = -1
        RadMr.Checked = False
        radMs.Checked = False
        radSpring.Checked = False
        RadSummer.Checked = False
        radFall.Checked = False
        cboCollege.SelectedIndex = -1
        cboHighSchool.SelectedIndex = -1
        Me.dgvParents.ClearSelection()
        txtStudentFirst.Focus()
    End Sub
    Private Sub btnAddParent_Click(sender As Object, e As EventArgs) Handles btnAddParent.Click
        AddParent.ShowDialog()
    End Sub

    Private Sub frmStudentInformation_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'OutreachDataSet.tblCollege' table. You can move, or remove it, as needed.
        Me.TblCollegeTableAdapter.Fill(Me.OutreachDataSet.tblCollege)
        'TODO: This line of code loads data into the 'OutreachDataSet.tblHighSchool' table. You can move, or remove it, as needed.
        Me.TblHighSchoolTableAdapter.Fill(Me.OutreachDataSet.tblHighSchool)
        'TODO: This line of code loads data into the 'OutreachDataSet.tblParent' table. You can move, or remove it, as needed.
        Me.TblParentTableAdapter.Fill(Me.OutreachDataSet.tblParent)
        dgvParents.DataSource = theParent.Parents
        radMr.Checked = False
        radMs.Checked = False
        cboCollege.SelectedIndex = -1
        cboHighSchool.SelectedIndex = -1
        Me.dgvParents.ClearSelection()
    End Sub

    Private Sub btnUnselect_Click(sender As Object, e As EventArgs) Handles btnUnselect.Click
        Me.dgvParents.ClearSelection()
    End Sub

    Private Sub btnCreateHighSchool_Click(sender As Object, e As EventArgs) Handles btnCreateHighSchool.Click
        AddHighSchool.ShowDialog()
    End Sub

    Private Sub btnSearchParent_Click(sender As Object, e As EventArgs) Handles btnSearchParent.Click
        Dim parentLastName As String = txtParentLast.Text
        If searchok() Then
            Try
                theParent.findParent(parentLastName)
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
            dgvParents.DataSource = theParent.findParent(parentLastName)
        End If
    End Sub
    Function searchok()
        If txtParentLast.Text = "" Then
            MessageBox.Show("Please enter a parent last name to search for")
            Return False
        Else
            Return True
        End If
    End Function

    Private Sub btnDisplayParents_Click(sender As Object, e As EventArgs) Handles btnDisplayParents.Click
        dgvParents.DataSource = theParent.Parents
    End Sub

    Private Sub btnCreateCollege_Click(sender As Object, e As EventArgs) Handles btnCreateCollege.Click
        AddCollege.ShowDialog()
    End Sub
End Class
