﻿Public Class AddCollege
    Dim theCollege As New College

    Private Sub btnAddCollege_Click(sender As Object, e As EventArgs) Handles btnAddCollege.Click
        If dataok() Then
            Dim collegeName As String = txtCollege.Text
            Try
                collegeName = collegeName.Substring(0, 1).ToUpper() + collegeName.Substring(1)
                theCollege.AddCollege(collegeName)
                MessageBox.Show("College successfully added.")
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
            'frmStudentInformation.cboHighSchool.DataSource = theCollege.getCollegeName
            'frmStudentInformation.cboCollege.Items.Clear()
            'Dim collegenames As Datasource = theCollege.getCollegeName
            'For Each row As DataRow In collegenames.Rows
            '    frmStudentInformation.cboCollege.Items.Add(row)
            'Next
            txtCollege.Text = ""
            Me.Close()
        End If
    End Sub

    Function dataok()
        If txtCollege.Text = "" Then
            MessageBox.Show("Please enter a college name.")
            txtCollege.Focus()
            Return False
        Else
            Return True
        End If
    End Function

    Private Sub btnCloseForm_Click(sender As Object, e As EventArgs) Handles btnCloseForm.Click
        Me.Close()
    End Sub
End Class