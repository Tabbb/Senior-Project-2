﻿Public Class frmStudentInformation
    Dim theStudent As New Student
    Dim theParent As New Parent
    Dim theHighSchool As New HighSchool
    Dim theCollege As New College

    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        'Determine if required information is valid
        If dataOk() Then
            'if the information is valid, get the inputted information from the user
            Dim StudentFirst As String = txtStudentFirst.Text
            Dim StudentMiddle As String = txtStudentMiddle.Text
            Dim StudentLast As String = txtStudentLast.Text
            Dim Gender As String
            If radMs.Checked = True Then
                Gender = "Female"
            Else
                Gender = "Male"
            End If
            Dim DateOfBirth As String = txtDOB.Text
            Dim Street As String = txtStreet.Text
            Dim State As String = cboState.SelectedIndex
            Dim ZipCode As String = txtZip.Text
            Dim City As String = txtCity.Text
            Dim HomeNumber As String = txtHome.Text
            Dim CellNumber As String = txtCell.Text
            Dim TransferStudent As Boolean
            If chkTransfer.Checked = True Then
                TransferStudent = True
            Else
                TransferStudent = False
            End If
            Dim Email As String = txtEmail.Text
            Dim GraduationYear As String = txtGradYear.Text
            Dim EnrollmentYear As String = txtEnroll.Text
            Dim GPA As Double
            If txtGPA.Text = "" Then
                GPA = 0
            Else
                GPA = CDbl(txtGPA.Text)
            End If
            Dim Major As String = txtMajor.Text
            Dim phase As String = cmbPhase.SelectedItem.ToString()
            Dim ACTScore As Integer
            If txtACT.Text = "" Then
                ACTScore = 0
            Else
                ACTScore = CInt(txtACT.Text)
            End If
            Dim SATScore As Integer
            If txtSAT.Text = "" Then
                SATScore = 0
            Else
                SATScore = CInt(txtSAT.Text)
            End If
            Dim ParentID As Integer = 1
            Dim ParentFirstName As String = txtParentFirst.Text
            Dim ParentLastName As String = txtParentLast.Text
            Dim ParentAlumni As Boolean
            If chkAlumni.Checked = True Then
                ParentAlumni = True
            Else
                ParentAlumni = False
            End If
            Dim CollegeID As Integer = 1
            Dim CollegeName As String = txtCollege.Text
            Dim HighSchoolID As Integer = 1
            Dim HighSchoolName As String = txtHS.Text



            'create a new parent record for the student record if the user inputted information into the parent text boxes
            If (ParentFirstName <> "" And ParentLastName <> "") Then
                Try

                Catch ex As Exception

                End Try
            End If

            'create a new high school record for the student record if the user inputted information into the high school text boxes
            If (HighSchoolName <> "") Then
                Try

                Catch ex As Exception

                End Try
            End If
            'create a new college record for the student record if the user inputted information into the college text boxes
            If (CollegeName <> "") Then
                Try

                Catch ex As Exception

                End Try
            End If
            'query the primary key for the new parent record, high school record, and/or college record if needed

            'create a new student record
            Try
                theStudent.insert(StudentFirst, StudentMiddle, StudentLast, Gender, Street, City, State, ZipCode, HomeNumber, CellNumber, Email, DateOfBirth,
                                        ACTScore, SATScore, GraduationYear, TransferStudent, GPA, EnrollmentYear, Major, phase, ParentID, HighSchoolID, CollegeID)
                MessageBox.Show("Student has successfully been added.")
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
            frmStudentDisplay.dgvResults.DataSource = theStudent.students

        End If

    End Sub
    'Used to determine if required information is valid
    Function dataOk()
        If txtStudentFirst.Text = "" Then
            MessageBox.Show("PLease enter the first name.")
            Return False
        ElseIf txtStudentLast.Text = "" Then
            MessageBox.Show("Please enter the last name.")
            Return False
            ' Or IsDate(CDate(txtDOB.Text)) = False'
        ElseIf txtDOB.Text = "" Then
            MessageBox.Show("Please enter a valid date of birth.")
            Return False
        ElseIf txtEmail.Text = "" Then
            MessageBox.Show("Please enter an email address.")
            Return False
        ElseIf txtGradYear.Text = "" Or IsNumeric(txtGradYear.Text) = False Then
            MessageBox.Show("Please enter a valid graduation year.")
            Return False
        ElseIf txtGPA.Text <> "" Then
            Dim result As Double = 0.0
            Try
                Dim GPA As Double = CDbl(txtGPA.Text)
            Catch ex As Exception
                MessageBox.Show("Please enter a valid GPA.")
                Return False
            End Try
        ElseIf cmbPhase.SelectedIndex = -1 Then
            MessageBox.Show("Please seleect a phase for the student.")
            Return False
        Else
                Return True
        End If
    End Function

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ' Clears form 
        Dim a As Control

        For Each a In Me.Controls
            If TypeOf a Is TextBox Then
                a.Text = Nothing
            End If
            If TypeOf a Is MaskedTextBox Then
                a.Text = Nothing
            End If
        Next
        chkAlumni.Checked = False
        chkTransfer.Checked = False

    End Sub

    Private Sub frmStudentInformation_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
