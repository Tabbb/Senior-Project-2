﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AddCollege
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtCollege = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.btnAddCollege = New System.Windows.Forms.Button()
        Me.btnCloseForm = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'txtCollege
        '
        Me.txtCollege.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCollege.Location = New System.Drawing.Point(203, 38)
        Me.txtCollege.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtCollege.Name = "txtCollege"
        Me.txtCollege.Size = New System.Drawing.Size(261, 24)
        Me.txtCollege.TabIndex = 41
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(56, 36)
        Me.Label20.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(139, 25)
        Me.Label20.TabIndex = 42
        Me.Label20.Text = "College name:"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(16, 11)
        Me.Label14.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(98, 20)
        Me.Label14.TabIndex = 43
        Me.Label14.Text = "Education:"
        '
        'btnAddCollege
        '
        Me.btnAddCollege.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAddCollege.Location = New System.Drawing.Point(61, 81)
        Me.btnAddCollege.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnAddCollege.Name = "btnAddCollege"
        Me.btnAddCollege.Size = New System.Drawing.Size(168, 65)
        Me.btnAddCollege.TabIndex = 44
        Me.btnAddCollege.Text = "Add College"
        Me.btnAddCollege.UseVisualStyleBackColor = True
        '
        'btnCloseForm
        '
        Me.btnCloseForm.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCloseForm.Location = New System.Drawing.Point(273, 81)
        Me.btnCloseForm.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnCloseForm.Name = "btnCloseForm"
        Me.btnCloseForm.Size = New System.Drawing.Size(168, 65)
        Me.btnCloseForm.TabIndex = 45
        Me.btnCloseForm.Text = "Close Form"
        Me.btnCloseForm.UseVisualStyleBackColor = True
        '
        'AddCollege
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(527, 161)
        Me.Controls.Add(Me.btnCloseForm)
        Me.Controls.Add(Me.btnAddCollege)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.txtCollege)
        Me.Controls.Add(Me.Label20)
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Name = "AddCollege"
        Me.Text = "Add College Form"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtCollege As TextBox
    Friend WithEvents Label20 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents btnAddCollege As Button
    Friend WithEvents btnCloseForm As Button
End Class
