﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AddHighSchool
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtHS = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.btnAddHighSchool = New System.Windows.Forms.Button()
        Me.btnCloseForm = New System.Windows.Forms.Button()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'txtHS
        '
        Me.txtHS.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtHS.Location = New System.Drawing.Point(178, 38)
        Me.txtHS.Name = "txtHS"
        Me.txtHS.Size = New System.Drawing.Size(161, 21)
        Me.txtHS.TabIndex = 0
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(27, 38)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(145, 20)
        Me.Label15.TabIndex = 31
        Me.Label15.Text = "High School Name:"
        '
        'btnAddHighSchool
        '
        Me.btnAddHighSchool.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAddHighSchool.Location = New System.Drawing.Point(31, 73)
        Me.btnAddHighSchool.Name = "btnAddHighSchool"
        Me.btnAddHighSchool.Size = New System.Drawing.Size(126, 53)
        Me.btnAddHighSchool.TabIndex = 1
        Me.btnAddHighSchool.Text = "Add High School"
        Me.btnAddHighSchool.UseVisualStyleBackColor = True
        '
        'btnCloseForm
        '
        Me.btnCloseForm.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCloseForm.Location = New System.Drawing.Point(213, 73)
        Me.btnCloseForm.Name = "btnCloseForm"
        Me.btnCloseForm.Size = New System.Drawing.Size(126, 53)
        Me.btnCloseForm.TabIndex = 32
        Me.btnCloseForm.Text = "Close Form"
        Me.btnCloseForm.UseVisualStyleBackColor = True
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(12, 9)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(85, 17)
        Me.Label14.TabIndex = 33
        Me.Label14.Text = "Education:"
        '
        'AddHighSchool
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(378, 137)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.btnCloseForm)
        Me.Controls.Add(Me.btnAddHighSchool)
        Me.Controls.Add(Me.txtHS)
        Me.Controls.Add(Me.Label15)
        Me.Name = "AddHighSchool"
        Me.Text = "Add High School Form"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtHS As TextBox
    Friend WithEvents Label15 As Label
    Friend WithEvents btnAddHighSchool As Button
    Friend WithEvents btnCloseForm As Button
    Friend WithEvents Label14 As Label
End Class
