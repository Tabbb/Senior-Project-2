﻿Public Class AddHighSchool
    Private Sub AddHighSchool_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class