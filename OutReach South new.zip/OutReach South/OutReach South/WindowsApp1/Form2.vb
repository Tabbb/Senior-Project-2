﻿Public Class frmStudentDisplay
    Dim theStudent As New Student
    'Load the data grid view with the records from the student table
    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'OutreachDataSet.tblCollege' table. You can move, or remove it, as needed.
        Me.TblCollegeTableAdapter.Fill(Me.OutreachDataSet.tblCollege)
        'TODO: This line of code loads data into the 'OutreachDataSet.tblHighSchool' table. You can move, or remove it, as needed.
        Me.TblHighSchoolTableAdapter.Fill(Me.OutreachDataSet.tblHighSchool)
        dgvResults.DataSource = theStudent.students
        Dim theHighSchools As New HighSchool
        Dim theColleges As New College
        'cboHighSchool.DataSource = theHighSchools.Highschool
        'cboCollege.DataSource = theColleges.College


    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        frmStudentInformation.ShowDialog()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Try
            Dim idIndex As String
            'determines what student is selected
            idIndex = dgvResults.Item(0, dgvResults.CurrentRow.Index).Value
            'deletes the selected employee
            theStudent.delete(idIndex)
            'update the data grid view with the new set of students
            dgvResults.DataSource = theStudent.students
            MessageBox.Show("The selected student was deleted successfully.")
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click

    End Sub

    Private Sub radJunior_CheckedChanged(sender As Object, e As EventArgs) Handles radJunior.CheckedChanged

    End Sub

    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click
        frmEditStudent.ShowDialog()
    End Sub
End Class