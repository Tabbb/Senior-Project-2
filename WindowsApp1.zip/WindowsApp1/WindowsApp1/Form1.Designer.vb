﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class radFall
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnSubmit = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtStudentFirst = New System.Windows.Forms.TextBox()
        Me.txtStudentMiddle = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.radMs = New System.Windows.Forms.RadioButton()
        Me.RadMr = New System.Windows.Forms.RadioButton()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtStreet = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtCity = New System.Windows.Forms.TextBox()
        Me.txtZip = New System.Windows.Forms.MaskedTextBox()
        Me.cboState = New System.Windows.Forms.ComboBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.tstNumb = New System.Windows.Forms.MaskedTextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.txtDOB = New System.Windows.Forms.MaskedTextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.txtHS = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.tctGradYear = New System.Windows.Forms.MaskedTextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.txtACT = New System.Windows.Forms.TextBox()
        Me.RadSummer = New System.Windows.Forms.RadioButton()
        Me.RadioButton4 = New System.Windows.Forms.RadioButton()
        Me.radSpring = New System.Windows.Forms.RadioButton()
        Me.txtSAT = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.txtCollege = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.txtEnroll = New System.Windows.Forms.MaskedTextBox()
        Me.txtStudentLast = New System.Windows.Forms.TextBox()
        Me.txtParentF = New System.Windows.Forms.TextBox()
        Me.txtPLast = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.chkAlumni = New System.Windows.Forms.CheckBox()
        Me.SuspendLayout()
        '
        'btnSubmit
        '
        Me.btnSubmit.Location = New System.Drawing.Point(407, 360)
        Me.btnSubmit.Name = "btnSubmit"
        Me.btnSubmit.Size = New System.Drawing.Size(75, 23)
        Me.btnSubmit.TabIndex = 0
        Me.btnSubmit.Text = "Submit"
        Me.btnSubmit.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(13, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(35, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Name"
        '
        'txtStudentFirst
        '
        Me.txtStudentFirst.Location = New System.Drawing.Point(217, 38)
        Me.txtStudentFirst.Name = "txtStudentFirst"
        Me.txtStudentFirst.Size = New System.Drawing.Size(100, 20)
        Me.txtStudentFirst.TabIndex = 2
        '
        'txtStudentMiddle
        '
        Me.txtStudentMiddle.Location = New System.Drawing.Point(378, 38)
        Me.txtStudentMiddle.Name = "txtStudentMiddle"
        Me.txtStudentMiddle.Size = New System.Drawing.Size(104, 20)
        Me.txtStudentMiddle.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(13, 42)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(57, 13)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Full Name:"
        '
        'radMs
        '
        Me.radMs.AutoSize = True
        Me.radMs.Location = New System.Drawing.Point(76, 40)
        Me.radMs.Name = "radMs"
        Me.radMs.Size = New System.Drawing.Size(42, 17)
        Me.radMs.TabIndex = 6
        Me.radMs.TabStop = True
        Me.radMs.Text = "Ms."
        Me.radMs.UseVisualStyleBackColor = True
        '
        'RadMr
        '
        Me.RadMr.AutoSize = True
        Me.RadMr.Location = New System.Drawing.Point(128, 40)
        Me.RadMr.Name = "RadMr"
        Me.RadMr.Size = New System.Drawing.Size(40, 17)
        Me.RadMr.TabIndex = 7
        Me.RadMr.TabStop = True
        Me.RadMr.Text = "Mr."
        Me.RadMr.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(178, 42)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(29, 13)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "First:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(327, 42)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(41, 13)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "Middle:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(492, 42)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(30, 13)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "Last:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(18, 95)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(45, 13)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "Address"
        '
        'txtStreet
        '
        Me.txtStreet.Location = New System.Drawing.Point(55, 120)
        Me.txtStreet.Name = "txtStreet"
        Me.txtStreet.Size = New System.Drawing.Size(416, 20)
        Me.txtStreet.TabIndex = 12
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(18, 120)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(35, 13)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "Street"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(333, 151)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(24, 13)
        Me.Label8.TabIndex = 14
        Me.Label8.Text = "City"
        '
        'txtCity
        '
        Me.txtCity.Location = New System.Drawing.Point(363, 148)
        Me.txtCity.Name = "txtCity"
        Me.txtCity.Size = New System.Drawing.Size(100, 20)
        Me.txtCity.TabIndex = 15
        '
        'txtZip
        '
        Me.txtZip.Location = New System.Drawing.Point(268, 147)
        Me.txtZip.Mask = "00000"
        Me.txtZip.Name = "txtZip"
        Me.txtZip.Size = New System.Drawing.Size(41, 20)
        Me.txtZip.TabIndex = 16
        Me.txtZip.ValidatingType = GetType(Integer)
        '
        'cboState
        '
        Me.cboState.FormattingEnabled = True
        Me.cboState.Items.AddRange(New Object() {"Alabama ", "Alaska ", "Arizona ", "Arkansas ", "California ", "Colorado ", "Connecticut ", "Delaware ", "Florida ", "Georgia ", "Hawaii ", "Idaho ", "Illinois Indiana ", "Iowa ", "Kansas ", "Kentucky ", "Louisiana ", "Maine ", "Maryland ", "Massachusetts ", "Michigan ", "Minnesota ", "Mississippi ", "Missouri ", "Montana Nebraska ", "Nevada ", "New Hampshire ", "New Jersey ", "New Mexico ", "New York ", "North Carolina ", "North Dakota ", "Ohio ", "Oklahoma ", "Oregon ", "Pennsylvania Rhode Island ", "South Carolina ", "South Dakota ", "Tennessee ", "Texas ", "Utah ", "Vermont ", "Virginia ", "Washington ", "West Virginia ", "Wisconsin ", "Wyoming"})
        Me.cboState.Location = New System.Drawing.Point(77, 147)
        Me.cboState.Name = "cboState"
        Me.cboState.Size = New System.Drawing.Size(121, 21)
        Me.cboState.TabIndex = 17
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(18, 151)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(35, 13)
        Me.Label9.TabIndex = 18
        Me.Label9.Text = "State:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(222, 151)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(22, 13)
        Me.Label10.TabIndex = 19
        Me.Label10.Text = "Zip"
        '
        'tstNumb
        '
        Me.tstNumb.Location = New System.Drawing.Point(112, 184)
        Me.tstNumb.Mask = "(999) 000-0000"
        Me.tstNumb.Name = "tstNumb"
        Me.tstNumb.Size = New System.Drawing.Size(86, 20)
        Me.tstNumb.TabIndex = 20
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(18, 188)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(81, 13)
        Me.Label11.TabIndex = 21
        Me.Label11.Text = "Phone Number:"
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(216, 360)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 23)
        Me.btnClear.TabIndex = 22
        Me.btnClear.Text = "Clear All"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'txtEmail
        '
        Me.txtEmail.Location = New System.Drawing.Point(256, 184)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(207, 20)
        Me.txtEmail.TabIndex = 23
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(218, 188)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(32, 13)
        Me.Label12.TabIndex = 24
        Me.Label12.Text = "Email"
        '
        'txtDOB
        '
        Me.txtDOB.Location = New System.Drawing.Point(547, 181)
        Me.txtDOB.Mask = "00/00/0000"
        Me.txtDOB.Name = "txtDOB"
        Me.txtDOB.Size = New System.Drawing.Size(70, 20)
        Me.txtDOB.TabIndex = 25
        Me.txtDOB.ValidatingType = GetType(Date)
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(465, 188)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(66, 13)
        Me.Label13.TabIndex = 26
        Me.Label13.Text = "Date of Birth"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(18, 216)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(55, 13)
        Me.Label14.TabIndex = 27
        Me.Label14.Text = "Education"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(18, 240)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(65, 13)
        Me.Label15.TabIndex = 28
        Me.Label15.Text = "High School"
        '
        'txtHS
        '
        Me.txtHS.Location = New System.Drawing.Point(89, 237)
        Me.txtHS.Name = "txtHS"
        Me.txtHS.Size = New System.Drawing.Size(176, 20)
        Me.txtHS.TabIndex = 29
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(295, 240)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(84, 13)
        Me.Label16.TabIndex = 30
        Me.Label16.Text = "Graduation Year"
        '
        'tctGradYear
        '
        Me.tctGradYear.Location = New System.Drawing.Point(385, 237)
        Me.tctGradYear.Mask = "####"
        Me.tctGradYear.Name = "tctGradYear"
        Me.tctGradYear.Size = New System.Drawing.Size(27, 20)
        Me.tctGradYear.TabIndex = 31
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(17, 299)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(43, 13)
        Me.Label17.TabIndex = 32
        Me.Label17.Text = "Scores:"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(25, 335)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(28, 13)
        Me.Label18.TabIndex = 33
        Me.Label18.Text = "ACT"
        '
        'txtACT
        '
        Me.txtACT.Location = New System.Drawing.Point(56, 328)
        Me.txtACT.Name = "txtACT"
        Me.txtACT.Size = New System.Drawing.Size(43, 20)
        Me.txtACT.TabIndex = 34
        '
        'RadSummer
        '
        Me.RadSummer.AutoSize = True
        Me.RadSummer.Location = New System.Drawing.Point(451, 308)
        Me.RadSummer.Name = "RadSummer"
        Me.RadSummer.Size = New System.Drawing.Size(95, 17)
        Me.RadSummer.TabIndex = 35
        Me.RadSummer.TabStop = True
        Me.RadSummer.Text = "Summer (June)"
        Me.RadSummer.UseVisualStyleBackColor = True
        '
        'RadioButton4
        '
        Me.RadioButton4.AutoSize = True
        Me.RadioButton4.Location = New System.Drawing.Point(451, 285)
        Me.RadioButton4.Name = "RadioButton4"
        Me.RadioButton4.Size = New System.Drawing.Size(83, 17)
        Me.RadioButton4.TabIndex = 36
        Me.RadioButton4.TabStop = True
        Me.RadioButton4.Text = "Fall (August)"
        Me.RadioButton4.UseVisualStyleBackColor = True
        '
        'radSpring
        '
        Me.radSpring.AutoSize = True
        Me.radSpring.Location = New System.Drawing.Point(451, 331)
        Me.radSpring.Name = "radSpring"
        Me.radSpring.Size = New System.Drawing.Size(101, 17)
        Me.radSpring.TabIndex = 37
        Me.radSpring.TabStop = True
        Me.radSpring.Text = "Spring (January)"
        Me.radSpring.UseVisualStyleBackColor = True
        '
        'txtSAT
        '
        Me.txtSAT.Location = New System.Drawing.Point(56, 360)
        Me.txtSAT.Name = "txtSAT"
        Me.txtSAT.Size = New System.Drawing.Size(43, 20)
        Me.txtSAT.TabIndex = 38
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(25, 363)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(28, 13)
        Me.Label19.TabIndex = 39
        Me.Label19.Text = "SAT"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(17, 268)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(102, 13)
        Me.Label20.TabIndex = 40
        Me.Label20.Text = "College(s) Attended:"
        '
        'txtCollege
        '
        Me.txtCollege.Location = New System.Drawing.Point(125, 267)
        Me.txtCollege.Name = "txtCollege"
        Me.txtCollege.Size = New System.Drawing.Size(197, 20)
        Me.txtCollege.TabIndex = 41
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(295, 9)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(99, 13)
        Me.Label21.TabIndex = 42
        Me.Label21.Text = "Student Information"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(178, 312)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(152, 13)
        Me.Label22.TabIndex = 43
        Me.Label22.Text = "Year you plan to enroll to USA "
        '
        'txtEnroll
        '
        Me.txtEnroll.Location = New System.Drawing.Point(360, 305)
        Me.txtEnroll.Mask = "####"
        Me.txtEnroll.Name = "txtEnroll"
        Me.txtEnroll.Size = New System.Drawing.Size(34, 20)
        Me.txtEnroll.TabIndex = 44
        '
        'txtStudentLast
        '
        Me.txtStudentLast.Location = New System.Drawing.Point(528, 38)
        Me.txtStudentLast.Name = "txtStudentLast"
        Me.txtStudentLast.Size = New System.Drawing.Size(100, 20)
        Me.txtStudentLast.TabIndex = 45
        '
        'txtParentF
        '
        Me.txtParentF.Location = New System.Drawing.Point(160, 73)
        Me.txtParentF.Name = "txtParentF"
        Me.txtParentF.Size = New System.Drawing.Size(100, 20)
        Me.txtParentF.TabIndex = 46
        '
        'txtPLast
        '
        Me.txtPLast.Location = New System.Drawing.Point(345, 73)
        Me.txtPLast.Name = "txtPLast"
        Me.txtPLast.Size = New System.Drawing.Size(100, 20)
        Me.txtPLast.TabIndex = 47
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(18, 73)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(96, 13)
        Me.Label23.TabIndex = 48
        Me.Label23.Text = "Parent Information:"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(125, 77)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(29, 13)
        Me.Label24.TabIndex = 49
        Me.Label24.Text = "First:"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(300, 77)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(30, 13)
        Me.Label25.TabIndex = 50
        Me.Label25.Text = "Last:"
        '
        'chkAlumni
        '
        Me.chkAlumni.AutoSize = True
        Me.chkAlumni.Location = New System.Drawing.Point(465, 77)
        Me.chkAlumni.Name = "chkAlumni"
        Me.chkAlumni.Size = New System.Drawing.Size(57, 17)
        Me.chkAlumni.TabIndex = 51
        Me.chkAlumni.Text = "Alumni"
        Me.chkAlumni.UseVisualStyleBackColor = True
        '
        'radFall
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(654, 395)
        Me.Controls.Add(Me.chkAlumni)
        Me.Controls.Add(Me.Label25)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.txtPLast)
        Me.Controls.Add(Me.txtParentF)
        Me.Controls.Add(Me.txtStudentLast)
        Me.Controls.Add(Me.txtEnroll)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.txtCollege)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.txtSAT)
        Me.Controls.Add(Me.radSpring)
        Me.Controls.Add(Me.RadioButton4)
        Me.Controls.Add(Me.RadSummer)
        Me.Controls.Add(Me.txtACT)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.tctGradYear)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.txtHS)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.txtDOB)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.txtEmail)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.tstNumb)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.cboState)
        Me.Controls.Add(Me.txtZip)
        Me.Controls.Add(Me.txtCity)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.txtStreet)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.RadMr)
        Me.Controls.Add(Me.radMs)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtStudentMiddle)
        Me.Controls.Add(Me.txtStudentFirst)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnSubmit)
        Me.Name = "radFall"
        Me.Text = "Student Information"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnSubmit As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents txtStudentFirst As TextBox
    Friend WithEvents txtStudentMiddle As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents radMs As RadioButton
    Friend WithEvents RadMr As RadioButton
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents txtStreet As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents txtCity As TextBox
    Friend WithEvents txtZip As MaskedTextBox
    Friend WithEvents cboState As ComboBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents tstNumb As MaskedTextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents btnClear As Button
    Friend WithEvents txtEmail As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents txtDOB As MaskedTextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents txtHS As TextBox
    Friend WithEvents Label16 As Label
    Friend WithEvents tctGradYear As MaskedTextBox
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents txtACT As TextBox
    Friend WithEvents RadSummer As RadioButton
    Friend WithEvents RadioButton4 As RadioButton
    Friend WithEvents radSpring As RadioButton
    Friend WithEvents txtSAT As TextBox
    Friend WithEvents Label19 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents txtCollege As TextBox
    Friend WithEvents Label21 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents txtEnroll As MaskedTextBox
    Friend WithEvents txtStudentLast As TextBox
    Friend WithEvents txtParentF As TextBox
    Friend WithEvents txtPLast As TextBox
    Friend WithEvents Label23 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents chkAlumni As CheckBox
End Class
