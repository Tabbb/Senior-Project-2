﻿Public Class Student
    'Create table adapter for student table
    Private adapterStudent As New OutreachDataSetTableAdapters.tblStudentTableAdapter
    Private queriesAdapter As New OutreachDataSetTableAdapters.QueriesTableAdapter

    'Create instance variables for Student table
    Private m_StudentFirst As String
    Private m_StudentMiddle As String
    Private m_StudentLast As String
    Private m_Gender As Boolean
    Private m_DateOfBirth As DateTime
    Private m_Street As String
    Private m_State As String
    Private m_ZipCode As String
    Private m_City As String
    Private m_HomeNumber As String
    Private m_CellNumber As String
    Private m_Email As String
    Private m_GraduationYear As Integer
    Private m_EnrollmentYear As String
    Private m_Classification As String
    Private m_GPA As Double
    Private m_Major As String
    Private m_ACTScore As Integer
    Private m_SATScore As Integer
    Private m_Phase As String
    Private m_ParentID As Integer
    Private m_CollegeID As Integer
    Private m_HighSchoolID As Integer
    Private m_StudentID As Integer

    'Create property blocks for each of the instance variables
    Public Property StudentFirst() As String
        Get
            Return m_StudentFirst
        End Get
        Set(value As String)
            value = m_StudentFirst
        End Set
    End Property
    Public Property StudentLast() As String
        Get
            Return m_StudentLast
        End Get
        Set(value As String)
            value = m_StudentLast
        End Set
    End Property
    Public Property StudentMiddle() As String
        Get
            Return m_StudentMiddle
        End Get
        Set(value As String)
            value = m_StudentMiddle
        End Set
    End Property
    Public Property Gender() As Boolean
        Get
            Return m_Gender
        End Get
        Set(value As Boolean)
            value = m_Gender
        End Set
    End Property
    Public Property DateOfBirth() As DateTime
        Get
            Return m_DateOfBirth
        End Get
        Set(value As DateTime)
            value = m_DateOfBirth
        End Set
    End Property
    Public Property Street() As String
        Get
            Return m_Street
        End Get
        Set(value As String)
            value = m_Street
        End Set
    End Property
    Public Property State() As String
        Get
            Return m_State
        End Get
        Set(value As String)
            value = m_State
        End Set
    End Property
    Public Property ZipCode() As String
        Get
            Return m_ZipCode
        End Get
        Set(value As String)
            value = m_ZipCode
        End Set
    End Property
    Public Property City() As String
        Get
            Return m_City
        End Get
        Set(value As String)
            value = m_City
        End Set
    End Property
    Public Property HomeNumber() As String
        Get
            Return m_HomeNumber
        End Get
        Set(value As String)
            value = m_HomeNumber
        End Set
    End Property
    Public Property CellNumber() As String
        Get
            Return m_CellNumber
        End Get
        Set(value As String)
            value = m_CellNumber
        End Set
    End Property
    Public Property Email() As String
        Get
            Return m_Email
        End Get
        Set(value As String)
            value = m_Email
        End Set
    End Property
    Public Property GraduationYear() As Integer
        Get
            Return m_GraduationYear
        End Get
        Set(value As Integer)
            value = m_GraduationYear
        End Set
    End Property
    Public Property EnrollmentYear() As String
        Get
            Return m_EnrollmentYear
        End Get
        Set(value As String)
            value = m_EnrollmentYear
        End Set
    End Property
    Public Property Classification() As String
        Get
            Return m_Classification
        End Get
        Set(value As String)
            value = m_Classification
        End Set
    End Property

    Public Property GPA() As Integer
        Get
            Return m_GPA
        End Get
        Set(value As Integer)
            value = m_GPA
        End Set
    End Property
    Public Property Major() As String
        Get
            Return m_Major
        End Get
        Set(value As String)
            value = m_Major
        End Set
    End Property
    Public Property ACTScore() As Integer
        Get
            Return m_ACTScore
        End Get
        Set(value As Integer)
            value = m_ACTScore
        End Set
    End Property
    Public Property SATScore() As Integer
        Get
            Return m_SATScore
        End Get
        Set(value As Integer)
            value = m_SATScore
        End Set
    End Property
    Public Property Phase() As String
        Get
            Return m_Phase
        End Get
        Set(value As String)
            value = m_Phase
        End Set
    End Property
    Public Property ParentID() As Integer
        Get
            Return m_ParentID
        End Get
        Set(value As Integer)
            value = m_ParentID
        End Set
    End Property
    Public Property HighSchoolID() As Integer
        Get
            Return m_HighSchoolID
        End Get
        Set(value As Integer)
            value = m_HighSchoolID
        End Set
    End Property
    Public Property CollegeID() As Integer
        Get
            Return m_CollegeID
        End Get
        Set(value As Integer)
            value = m_CollegeID
        End Set
    End Property
    Public Property StudentID() As Integer
        Get
            Return m_StudentID
        End Get
        Set(value As Integer)
            value = m_StudentID
        End Set
    End Property
    'Create readonly property for students table
    Public ReadOnly Property students As DataTable
        Get
            Dim studentTable As DataTable = adapterStudent.GetData()
            Return studentTable
        End Get
    End Property
    'Create default constructor for student
    Public Sub New()
        m_StudentFirst = ""
        m_StudentMiddle = ""
        m_StudentLast = ""
        m_Gender = True
        m_DateOfBirth = "01/01/2001"
        m_Street = ""
        m_State = ""
        m_ZipCode = ""
        m_City = ""
        m_HomeNumber = ""
        m_CellNumber = ""
        m_Email = ""
        m_GraduationYear = 0
        m_EnrollmentYear = ""
        m_Classification = ""
        m_GPA = 0.0
        m_Major = ""
        m_ACTScore = 0
        m_SATScore = 0
        m_Phase = ""
        m_ParentID = 0
        m_CollegeID = 0
        m_HighSchoolID = 0
    End Sub
    'Need to make some of these parameters optional because we won't require all of them to create a student 

    'Create constructor for student with paremeters
    Public Sub New(ByVal p_StudentFirst As String, ByVal p_StudentMiddle As String, ByVal p_StudentLast As String,
                   ByVal p_Gender As Boolean, ByVal p_DateOfBirth As String, ByVal p_Street As String, ByVal p_State As String,
                   ByVal p_ZipCode As String, ByVal p_City As String, ByVal p_HomeNumber As String, ByVal p_CellNumber As String,
                   ByVal p_Email As String, ByVal p_GraduationYear As Integer, ByVal p_EnrollmentYear As String, ByVal p_classification As String,
                   ByVal p_GPA As Double, ByVal p_Major As String, ByVal p_ACTScore As Integer, ByVal p_SATScore As Integer, ByVal p_Phase As String, ByVal p_ParentID As Integer,
                   ByVal p_CollegeID As Integer, ByVal p_HighSchoolID As Integer)
        m_StudentFirst = p_StudentFirst
        m_StudentMiddle = p_StudentMiddle
        m_StudentLast = p_StudentLast
        m_Gender = p_Gender
        m_DateOfBirth = p_DateOfBirth
        m_Street = p_Street
        m_State = p_State
        m_ZipCode = p_ZipCode
        m_City = p_City
        m_HomeNumber = p_HomeNumber
        m_CellNumber = p_CellNumber
        m_Email = p_Email
        m_GraduationYear = p_GraduationYear
        m_EnrollmentYear = p_EnrollmentYear
        m_Classification = p_classification
        m_GPA = p_GPA
        m_Major = p_Major
        m_ACTScore = p_ACTScore
        m_SATScore = p_SATScore
        m_Phase = p_Phase
        m_ParentID = p_ParentID
        m_CollegeID = p_CollegeID
        m_HighSchoolID = p_HighSchoolID
    End Sub
    Public Function insert(ByVal p_firstName As String, ByVal p_middleName As String, ByVal p_lastName As String, ByVal p_gender As String,
                           ByVal p_street As String, ByVal p_city As String, ByVal p_st As String, ByVal p_zip As String, ByVal p_homePhone As String,
                           ByVal p_cellPhone As String, ByVal p_email As String, ByVal p_DOB As String, ByVal p_ACTscore As Integer,
                           ByVal p_SATscore As Integer, ByVal p_graduationYear As String, ByVal p_transferStudent As Boolean,
                           ByVal p_GPA As Double, ByVal p_enrollmentDate As String, p_classification As String, ByVal p_major As String, ByVal p_phase As String,
                           ByVal p_ParentID As Integer, ByVal p_HighSchoolID As Integer, ByVal p_CollegeID As Integer) As Boolean
        Return queriesAdapter.AddStudent(p_firstName, p_middleName, p_lastName, p_gender, p_street, p_city, p_st, p_zip, p_homePhone, p_cellPhone, p_email, p_DOB,
                                         p_ACTscore, p_SATscore, p_graduationYear, p_transferStudent, p_GPA, p_enrollmentDate, p_classification, p_major, p_phase, p_ParentID, p_HighSchoolID, p_CollegeID) > 0
    End Function
    Public Function update(ByVal p_firstName As String, ByVal p_middleName As String, ByVal p_lastName As String, ByVal p_gender As String,
                           ByVal p_street As String, ByVal p_city As String, ByVal p_st As String, ByVal p_zip As String, ByVal p_homePhone As String,
                           ByVal p_cellPhone As String, ByVal p_email As String, ByVal p_DOB As String, ByVal p_ACTscore As Integer,
                           ByVal p_SATscore As Integer, ByVal p_graduationYear As String, ByVal p_transferStudent As Boolean,
                           ByVal p_GPA As Double, ByVal p_enrollmentDate As String, ByVal p_classification As String, ByVal p_major As String, ByVal p_phase As String,
                           ByVal p_ParentID As Integer, ByVal p_HighSchoolID As Integer, ByVal p_CollegeID As Integer, ByVal p_StudentID As Integer) As Boolean
        Return queriesAdapter.UpdateStudent(p_StudentID, p_firstName, p_middleName, p_lastName, p_gender, p_street, p_city, p_st, p_zip, p_homePhone, p_cellPhone, p_email, p_DOB,
                                         p_ACTscore, p_SATscore, p_graduationYear, p_transferStudent, p_GPA, p_enrollmentDate, p_classification, p_major, p_phase, p_ParentID, p_HighSchoolID, p_CollegeID) > 0
    End Function
    Public Function delete(ByVal p_studentID As Integer) As Boolean
        Return queriesAdapter.DeleteStudent(p_studentID)
    End Function
End Class


'Parent Class
Public Class Parent
    'Table adapter for the Parent table 
    Private adapterParent As New OutreachDataSetTableAdapters.tblParentTableAdapter
    Private queriesAdapter As New OutreachDataSetTableAdapters.QueriesTableAdapter

    'instance variables for parent class
    Private m_ParentId As Integer
    Private m_ParentFirst As String
    Private m_ParentLast As String
    Private m_Alumni As Boolean


    'Read only property for the get data query
    Public ReadOnly Property Parents As DataTable
        Get
            Dim parentTable As DataTable = adapterParent.GetData()
            Return parentTable
        End Get
    End Property

    Public Property ParentFirst() As String
        Get
            Return m_ParentFirst
        End Get
        Set(value As String)
            m_ParentLast = value
        End Set
    End Property

    Public Property ParentLast() As String
        Get
            Return m_ParentLast
        End Get
        Set(value As String)
            m_ParentLast = value
        End Set
    End Property

    Public Property Alumni() As Boolean
        Get
            Return m_Alumni
        End Get
        Set(value As Boolean)
            m_Alumni = value
        End Set
    End Property

    Public Property ParentId() As Integer
        Get
            Return m_ParentId
        End Get
        Set(value As Integer)
            m_ParentLast = value
        End Set
    End Property
    Public Sub New()
        m_ParentFirst = ""
        m_ParentLast = ""
        m_Alumni = False
        m_ParentId = 0
    End Sub
    Public Sub New(ByVal p_ParentFirst As String, ByVal p_ParentLast As String, ByVal p_Alumni As Boolean, ByVal p_ParentId As Integer)
        m_ParentFirst = p_ParentFirst
        m_ParentLast = p_ParentLast
        m_Alumni = p_Alumni
        m_ParentId = p_ParentId
    End Sub
    Public Function insert(ByVal p_ParentFirst As String, ByVal p_ParentLast As String, ByVal p_ParentAlumni As Boolean) As Boolean
        Return queriesAdapter.AddParent(p_ParentFirst, p_ParentLast, p_ParentAlumni) > 0
    End Function
    'Public Function update(ByVal p_ParentFirst As String, ByVal p_ParentLast As String, ByVal p_ParentAlumni As Boolean, p_ParentID As Integer) As Boolean
    '   Return queriesAdapter.updateparent(ParentFirst, ParentLast, ParentAlumni, ParentId) > 0
    'End Function
End Class


'College Class
Public Class College
    'instance variables for the college class
    Private m_collegeId As Integer
    Private m_collegeName As String

    'Table adapter for the college table 
    Private adapterCollege As New OutreachDataSetTableAdapters.tblCollegeTableAdapter
    Private queriesAdapter As New OutreachDataSetTableAdapters.QueriesTableAdapter

    'Read only property for the get data query
    Public ReadOnly Property College As DataTable
        Get
            Dim collegeTable As DataTable = adapterCollege.GetData()
            Return collegeTable
        End Get
    End Property
    Public Property CollegeName() As String
        Get
            Return m_collegeName
        End Get
        Set(value As String)
            m_collegeName = value
        End Set
    End Property
    Public Property CollegeId() As Integer
        Get
            Return m_collegeId
        End Get
        Set(value As Integer)
            m_collegeId = value
        End Set
    End Property
    Public Sub New()
        m_collegeName = ""
        m_collegeId = 0
    End Sub

    Public Sub New(ByVal p_CollegeName As String, ByVal p_CollegeId As Integer)
        m_collegeName = p_CollegeName
        m_collegeId = p_CollegeId
    End Sub

    Public Function AddCollege(ByVal p_collegename As String)
        Return queriesAdapter.AddCollege(p_collegename)
    End Function

End Class


'HighSchool Class
Public Class HighSchool
    Private m_highSchoolId As Integer
    Private m_highschoolName As String

    'Table adapter for the high school table 
    Private adapterHighSchool As New OutreachDataSetTableAdapters.tblHighSchoolTableAdapter
    Private queriesAdapter As New OutreachDataSetTableAdapters.QueriesTableAdapter

    'Read only property for the get data query
    Public ReadOnly Property Highschool As DataTable
        Get
            Dim highschoolTable As DataTable = adapterHighSchool.GetData()
            Return highschoolTable
        End Get
    End Property
    'Create property block for each of the instance variables
    Public Property HighSchoolName() As String
        Get
            Return m_highschoolName
        End Get
        Set(value As String)
            m_highschoolName = value
        End Set
    End Property
    Public Property HighSchoolId() As Integer
        Get
            Return m_highSchoolId
        End Get
        Set(value As Integer)
            m_highschoolName = value
        End Set
    End Property
    Public Sub New()
        m_highschoolName = ""
        m_highSchoolId = 0
    End Sub

    Public Sub New(ByVal p_highSchoolName As String, ByVal p_HighSchoolId As Integer)
        m_highschoolName = p_highSchoolName
        m_highSchoolId = p_HighSchoolId
    End Sub

    Public Function AddHighschool(ByVal p_highschoolname As String)
        Return queriesAdapter.Addhighschool(p_highschoolname)
    End Function

End Class
